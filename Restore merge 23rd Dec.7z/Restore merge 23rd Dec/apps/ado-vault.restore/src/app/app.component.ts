import { Component } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-root',
  template: '',
})
export class AppComponent {

}
