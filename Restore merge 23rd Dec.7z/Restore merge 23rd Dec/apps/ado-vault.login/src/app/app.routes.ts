import { MsalLoginComponent } from './components/msal-login.component';
import { Route } from '@angular/router';
import { AuthGuard, PageName, PermissionsList } from '@ado-bcp-ui/core';
import { UnAuthorizedComponent } from '@ado-bcp-ui/shared-component';

export const appRoutes: Route[] = [
  {
    path: PageName.DASHBOARD,
    loadChildren: () =>
      import('ado-vault.dashboard/Module').then((m) => m.RemoteEntryModule),
    canActivate: [AuthGuard],
    data: { roles: [] },
  },
  {
    path: PageName.BACKUP,
    loadChildren: () =>
      import('ado-vault.backup/Module').then((m) => m.RemoteEntryModule),
    canActivate: [AuthGuard],
    data: {
      roles: [PermissionsList.BACKUP_READ, PermissionsList.BACKUP_WRITE],
    },
  },
  {
    path: PageName.RESTORE,
    loadChildren: () =>
      import('ado-vault.restore/Module').then((m) => m.RemoteEntryModule),
    canActivate: [AuthGuard],
    data: {
      roles: [PermissionsList.RESTORE_READ, PermissionsList.RESTORE_WRITE],
    },
  },
  {
    path: PageName.USER_MANAGEMEMT,
    loadChildren: () =>
      import('ado-vault.user-management/Module').then(
        (m) => m.RemoteEntryModule
      ),
    canActivate: [AuthGuard],
    data: {
      roles: [
        PermissionsList.USER_MANAGEMENT_WRITE,
        PermissionsList.USER_MANAGEMENT_READ,
      ],
    },
  },
  {
    path: PageName.NOTIFICATION,
    loadChildren: () =>
      import('ado-vault.notification/Module').then((m) => m.RemoteEntryModule),
    canActivate: [AuthGuard],
    data: {
      roles: [PermissionsList.SETTING_READ, PermissionsList.SETTING_WRITE],
    },
  },
  {
    path: PageName.STORAGE,
    loadChildren: () =>
      import('ado-vault.storage/Module').then((m) => m.RemoteEntryModule),
    canActivate: [AuthGuard],
    data: {
      roles: [PermissionsList.SETTING_READ, PermissionsList.SETTING_WRITE],
    },
  },
  {
    path: PageName.ROLE,
    loadChildren: () =>
      import('ado-vault.role/Module').then((m) => m.RemoteEntryModule),
    canActivate: [AuthGuard],
    data: {
      roles: [PermissionsList.SETTING_READ, PermissionsList.SETTING_WRITE],
    },
  },
  {
    path: PageName.REPORT,
    loadChildren: () =>
      import('ado-vault.report/Module').then((m) => m.RemoteEntryModule),
    canActivate: [AuthGuard],
    data: {
      roles: [PermissionsList.REPORT_WRITE, PermissionsList.REPORT_READ],
    },
  },
  {
    path: PageName.BACKUP_REPORT,
    loadChildren: () =>
      import('ado-vault.report/Module').then((m) => m.RemoteEntryModule),
    canActivate: [AuthGuard],
    data: {
      roles: [PermissionsList.REPORT_WRITE, PermissionsList.REPORT_READ],
    },
  },
  {
    path: PageName.RESTORE_REPORT,
    loadChildren: () =>
      import('ado-vault.report/Module').then((m) => m.RemoteEntryModule),
    canActivate: [AuthGuard],
    data: {
      roles: [PermissionsList.REPORT_WRITE, PermissionsList.REPORT_READ],
    },
  },
  {
    path: PageName.LOG_REPORT,
    loadChildren: () =>
      import('ado-vault.report/Module').then((m) => m.RemoteEntryModule),
    canActivate: [AuthGuard],
    data: {
      roles: [PermissionsList.REPORT_WRITE, PermissionsList.REPORT_READ],
    },
  },
  {
    path: PageName.INTEGRATION,
    loadChildren: () =>
      import('ado-vault.integration/Module').then((m) => m.RemoteEntryModule),
    canActivate: [AuthGuard],
    data: {
      roles: [PermissionsList.SETTING_READ, PermissionsList.SETTING_WRITE],
    },
  },
  {
    path: PageName.ENTITY,
    loadChildren: () =>
      import('ado-vault.entity/Module').then((m) => m.RemoteEntryModule),
    canActivate: [AuthGuard],
    data: {
      roles: [PermissionsList.SETTING_READ, PermissionsList.SETTING_WRITE],
    },
  },
  {
    path: PageName.COMPANY,
    loadChildren: () =>
      import('ado-vault.company/Module').then((m) => m.RemoteEntryModule),
    canActivate: [AuthGuard],
    data: {
      roles: [PermissionsList.SETTING_READ, PermissionsList.SETTING_WRITE],
    },
  },
  {
    path: PageName.UNAUTHORIZED,
    component: UnAuthorizedComponent,
    canActivate: [AuthGuard],
    data: {
      roles: [],
    },
  },
  {
    path: PageName.LOGIN,
    component: MsalLoginComponent,
  },
  {
    path: '**',
    redirectTo: PageName.LOGIN,
    pathMatch: 'full',
  },
];
