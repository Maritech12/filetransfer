const BACKUPDETAILS = 
  {
    transactionType: 'backup',
    emaiId: 'vigneshraj.asokan@sea.live',
    title: 'Backup',
    organizationName: 'clarksonscloud',
    project: 'Project 1',
  }

const COLUMNSSUBHEADER = [
  'entity',
  'subEntity',
  'backupFileName',
  'insertedTime',
  'completedTime',
  'status',
  'action',
];

const COLUMNSHEADERDETAILS = [
  {
    name: 'Entities',
    value: COLUMNSSUBHEADER[0],
  },
  {
    name: 'Sub Entities',
    value: COLUMNSSUBHEADER[1],
  },
  {
    name: 'Blob',
    value: COLUMNSSUBHEADER[2],
  },
  {
    name: 'Initiated At',
    value: COLUMNSSUBHEADER[3],
  },
  {
    name: 'Completed At',
    value: COLUMNSSUBHEADER[4],
  },
  {
    name: 'Status',
    value: COLUMNSSUBHEADER[5],
  },
  {
    name: 'Action',
    value: COLUMNSSUBHEADER[6],
  },
];

const PERIODDETAILS = [
  {
    key: '30 Days',
    value: '30',
  },
  {
    key: '60 Days',
    value: '60',
  },
  {
    key: '90 Days',
    value: '90',
  },
  {
    key: '180 Days',
    value: '180',
  },
  {
    key: '365 Days',
    value: '365',
  },
];


export { BACKUPDETAILS, COLUMNSHEADERDETAILS, PERIODDETAILS, COLUMNSSUBHEADER };
