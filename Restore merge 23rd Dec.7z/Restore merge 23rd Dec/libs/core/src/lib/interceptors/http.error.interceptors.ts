import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { UserService } from '../services/user/user.service';
import { ErrorList, PageName } from '../model/shared.model';
import { environment } from '../environments/environment';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  constructor(private userService: UserService) {}

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      catchError((err) => {        
        if (
          [ErrorList.UNAUTHORIZED, ErrorList.FORBIDDEN].indexOf(err.status) !==
          -1
        ) {
          //  Redirect to the Unauthorized Page
          location.href = `${environment.return_url}/${PageName.UNAUTHORIZED}`;
        }

        const error = err.error.message || err.statusText;
        return throwError(() => new Error(error));
      })
    );
  }
}
