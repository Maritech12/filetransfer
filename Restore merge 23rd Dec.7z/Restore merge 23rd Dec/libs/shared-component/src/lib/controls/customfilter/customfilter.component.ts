import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-customfilter',
  templateUrl: './customfilter.component.html',
  styleUrls: ['./customfilter.component.scss'],
})
export class CustomfilterComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
