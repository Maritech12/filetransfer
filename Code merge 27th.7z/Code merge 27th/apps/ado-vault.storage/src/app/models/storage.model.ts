export class StorageModel {}
