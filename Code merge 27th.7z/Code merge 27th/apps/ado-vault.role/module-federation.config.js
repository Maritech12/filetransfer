module.exports = {
  name: 'ado-vault.role',
  exposes: {
    './Module': 'apps/ado-vault.role/src/app/remote-entry/entry.module.ts',
  },
};
