export class CompanyModel {}
