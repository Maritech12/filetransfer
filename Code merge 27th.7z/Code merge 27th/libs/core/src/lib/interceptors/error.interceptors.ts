import { ErrorHandler, Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable()
export class MyErrorHandler implements ErrorHandler {
  constructor() {}
  handleError(error: any):  Observable<any> {
    if (error) {
      console.log('Error Caught ',error);
    }
    return of('Error Caught')
  }
}
