interface InotificationElement {
  title: string | undefined;
  subTitle: string | undefined;
}

interface IPermissions {
  permissionid?: number;
  permissionname: string;
  dissplayname?: string;
  read: boolean;
  write: boolean;
  permissionRoleMappings?: [];
}

interface IUser {
  email: string;
  token: string;
  username: string | undefined;
  name: string | undefined;
  permissions: IPermissions[];
}
interface IReadWriteAccess {
  read: boolean;
  write: boolean;
}

export { InotificationElement, IUser, IPermissions, IReadWriteAccess };
