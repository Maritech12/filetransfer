/* eslint-disable @nrwl/nx/enforce-module-boundaries */
import { SharedService } from '@ado-bcp-ui/core';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-tile',
  templateUrl: './tile.component.html',
  styleUrls: ['./tile.component.scss'],
})
export class TileComponent implements OnInit {
  constructor(private sharedService: SharedService) {}

  titleElement: any;

  ngOnInit(): void {
    /* For testing we created
    // this.sharedService.getDashboardTileDetails().subscribe((data) => {
    //   this.titleElement = data;
    // });

    // this.sharedService._STile_Data.subscribe((val) => {
    //   console.log("title",val);
    //   this.titleElement = val;
    //   debugger;
    // });

    // this.sharedService._SMessage.subscribe((val) => {
    //   console.log("messagestoree",val);
    //   this.titleElement = val;
    //   debugger;
    // });
    */
  }
}
