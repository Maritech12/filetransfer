import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'ado-bcp-ui-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss'],
})
export class TableComponent implements OnInit {
  @Input() from = '';
  @Input() tableSource!: any;
  @Input() displayedColumnHeader: any;
  @Input() displayedColumnSubHeader: any;
  @Output() onChanged: EventEmitter<any> = new EventEmitter<any>();
  @Input() backupRestoreDetails: any;
  @Input() actionDetails: any;
  @Input() popOverTitleDetails: any;

  dataSource = new MatTableDataSource(this.tableSource);
  @ViewChild('paginator') paginator!: MatPaginator;
  @ViewChild('paginatorPageSize') paginatorPageSize!: MatPaginator;

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
  ngOnInit() {
    this.dataSource = new MatTableDataSource(this.tableSource);
  }
}
