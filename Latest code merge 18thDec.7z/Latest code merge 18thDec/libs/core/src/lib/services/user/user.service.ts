import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject, ReplaySubject, of } from 'rxjs';
import { ApiService, JwtService, Iuser, IPermissions } from '@ado-bcp-ui/core';
import { map, distinctUntilChanged } from 'rxjs/operators';

@Injectable()
export class UserService {
  private currentUserSubject = new BehaviorSubject<Iuser>({} as Iuser);
  public currentUser = this.currentUserSubject
    .asObservable()
    .pipe(distinctUntilChanged());

  private isAuthenticatedSubject = new ReplaySubject<boolean>(1);
  public isAuthenticated = this.isAuthenticatedSubject.asObservable();

  constructor(
    private apiService: ApiService,
    private http: HttpClient,
    private jwtService: JwtService
  ) {}

  // Verify JWT in localstorage with server & load user's info.
  // This runs once on application startup.
  populate() {
    // If JWT detected, attempt to get & store user's info
    if (this.jwtService.getToken()) {
      this.apiService.get('/user').subscribe({
        next: (data) => this.setAuth(data.user),
        error: (err) => this.purgeAuth(),
      });
    } else {
      // Remove any potential remnants of previous auth states
      this.purgeAuth();
    }
  }

  setAuth(user: Iuser) {
    // Save JWT sent from server in localstorage
    this.jwtService.saveToken(user.token);
    // Set current user data into observable
    this.currentUserSubject.next(user);

    this.jwtService.saveUser(user);
    // Set isAuthenticated to true
    this.isAuthenticatedSubject.next(true);
  }

  purgeAuth() {
    // Remove JWT from localstorage
    this.jwtService.destroyToken();
    // Set current user to an empty object
    this.currentUserSubject.next({} as Iuser);
    // Set auth status to false
    this.isAuthenticatedSubject.next(false);
    //Remove User Details from localstorage
    this.jwtService.destroyUser();
  }

  attemptAuth(type: string, credentials: any): Observable<Iuser> {
    const route = type === 'login' ? '/login' : '';
    return this.apiService.post('/users' + route, { user: credentials }).pipe(
      map((data) => {
        this.setAuth(data.user);
        return data;
      })
    );
  }

  getCurrentUser(): Iuser {
    return this.currentUserSubject.value;
  }

  getCurrentUserDetails(): Iuser {
    let User: Iuser;
    User = this.jwtService.getUser();
    if (User.token != '') {
      this.isAuthenticatedSubject.next(true);
    }
    return User;
  }

  // Update the user on the server (email, pass, etc)
  update(Iuser: any): Observable<Iuser> {
    return this.apiService.put('/user', { Iuser }).pipe(
      map((data) => {
        // Update the currentUser observable
        this.currentUserSubject.next(data.user);
        return data.user;
      })
    );
  }

  getPagePermissions(pageName: string): Observable<IPermissions[]> {
    let userDetails = this.getCurrentUserDetails();
    let permissionAccess: IPermissions[] = [];
    if (userDetails.permissions.length > 0) {
      permissionAccess = userDetails.permissions
        .map((access: IPermissions) => {
          if (pageName.toUpperCase() == access.permissionname.toUpperCase()) {
            return access;
          } else {
            return {
              permissionname: '',
              read: false,
              write: false,
            };
          }
        })
        .filter((val: IPermissions) => val.permissionname != '');
    }
    if (permissionAccess.length < 1) {
      permissionAccess.push({
        read: false,
        write: false,
        permissionname: '',
      });
    }
    return of(permissionAccess);
  }


  getPageRolePermissions(pagename: string[]): string[] {
    let currentUser: Iuser = this.getCurrentUserDetails();
    let permissionAccess: string[] = [];
    if (currentUser.permissions.length > 0) {
      if (pagename.length > 0) {
        permissionAccess = currentUser.permissions
          .map((access: IPermissions) => {
            let accesType: string = '';
            if (access.read || access.write) {
              accesType = access.permissionname;
            }
            return accesType;
          })
          .filter((val) => pagename.includes(val.toUpperCase()));
      }
    }
    return permissionAccess;
  }
}
