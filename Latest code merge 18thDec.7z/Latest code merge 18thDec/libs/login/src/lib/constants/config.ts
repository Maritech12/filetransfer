export enum Config {
  CLIENTID = '5dbedbc5-2213-435c-8f00-e5e47c22b98a',
  AUTHORITY = 'https://login.microsoftonline.com/',
  DOMAIN = 'Devtestmobius.onmicrosoft.com',
  SCOPE = 'api://d1d545be-c323-40d2-9a53-d8b52b0742b5/readWrite',
  LOCALSTORAGE = 'localStorage',
  PROTECTED_RESOURCE_MAP = 'https://graph.microsoft.com/v1.0/me',
  USER_READ = 'user.read',
  //return_url='https://vault-dev-ui.sea.live'
  return_url='http://localhost:4200'
}