const RESTOREDETAILS = {
  transactionType: 'restore',
  CREATETITLE: 'Restore',
  CENTER: 'center',
  TOP: 'top',
};

const COLUMNSSUBHEADER = [
  'entity',
  'subEntity',
  'backupFileName',
  'insertedTime',
  'completedTime',
  'status',
  'action',
];

const COLUMNSHEADERDETAILS = [
  {
    name: 'Entities',
    value: COLUMNSSUBHEADER[0],
  },
  {
    name: 'Sub Entities',
    value: COLUMNSSUBHEADER[1],
  },
  {
    name: 'Blob',
    value: COLUMNSSUBHEADER[2],
  },
  {
    name: 'Initiated At',
    value: COLUMNSSUBHEADER[3],
  },
  {
    name: 'Completed At',
    value: COLUMNSSUBHEADER[4],
  },
  {
    name: 'Status',
    value: COLUMNSSUBHEADER[5],
  },
  {
    name: 'Action',
    value: COLUMNSSUBHEADER[6],
  },
];

const PERIODDETAILS = [
  {
    key: '30 Days',
    value: '30',
  },
  {
    key: '60 Days',
    value: '60',
  },
  {
    key: '90 Days',
    value: '90',
  },
  {
    key: '180 Days',
    value: '180',
  },
  {
    key: '365 Days',
    value: '365',
  },
];

const ERRORCLASS = {
  SNACKBARDANGER: 'snackbar-danger',
  SNACKBARSUCCESS: 'snackbar-success',
  SNACKBARWARNING: 'snackbar-warning',
  SNACKBARINFO: 'snackbar-info',
};

export {
  RESTOREDETAILS,
  COLUMNSHEADERDETAILS,
  PERIODDETAILS,
  COLUMNSSUBHEADER,
  ERRORCLASS,
};
