import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { COLUMNHEADER } from '../constants/sharedConstant';

@Component({
  selector: 'ado-bcp-ui-pop-over',
  templateUrl: './pop-over.component.html',
  styleUrls: ['./pop-over.component.scss'],
})
export class PopOverComponent implements OnInit {
  columnHeaderDetails = COLUMNHEADER;
  @Input() popOverDetails: any;
  @Input() popOverTitleDetails!: string;
  @Input() createTitle: any;
  loading: boolean = true;
  ngOnInit() {}
}
