import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'ado-bcp-ui-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss'],
})
export class TableComponent implements OnInit {
  @Input() from = '';
  @Input() tableDetails!: any;
  @Input() displayedColumnHeader: any;
  @Input() displayedColumnSubHeader: any;
  @Output() onChanged: EventEmitter<any> = new EventEmitter<any>();
  @Input() backupRestoreDetails: any;
  @Input() popOverTitleDetails: any;
  @Input() loading:any;

  dataSource = new MatTableDataSource(this.tableDetails);
  @ViewChild('paginator') paginator!: MatPaginator;
  @ViewChild('paginatorPageSize') paginatorPageSize!: MatPaginator;

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
  ngOnInit() {
    this.dataSource = new MatTableDataSource(this.tableDetails);
  }
}
