const COLUMNHEADER = [
  { title: 'Entity', key: 'entityName' },
  { title: 'TransactionType', key: 'transactionType' },
  { title: 'Backup Details', key: 'completedTime' },
  { title: 'Activity Log', key: 'activitylog' },
  { title: 'Blob Storage', key: 'backupFileName' },
  { title: 'User IP Address', key: 'ipAddress' },
  { title: 'Error Code ', key: 'errorCode' },
  { title: 'Type of error', key: 'errorType' },
  { title: 'Error message', key: 'errorMessage' },
  { title: 'Component name', key: 'errorComponentName' },
  { title: 'Detailed failed reason', key: 'stackTrace' },
  { title: 'Running Status', key: 'percentage' },
  { title: 'Initiated At', key: 'completedTime' },
  { title: 'Initiated By', key: 'userName' },
  { title: 'Initiator Email', key: 'userEmail' },
  { title: 'Backup Region', key: 'regionName' },
  { title: 'Container Name', key: 'container' },
  { title: 'Storage Account', key: 'blobName' },
];

const EVERYDETAILS = [
  {
    key: 'Daily',
    value: 'D',
  },
  {
    key: 'Weekly',
    value: 'W',
  },
  {
    key: 'Monthly',
    value: 'M',
  },
];

const HOURDETAILS = [
  {
    key: '01',
    value: '1',
  },
  {
    key: '02',
    value: '2',
  },
  {
    key: '03',
    value: '3',
  },
  {
    key: '04',
    value: '4',
  },
  {
    key: '05',
    value: '5',
  },
  {
    key: '06',
    value: '6',
  },
  {
    key: '07',
    value: '7',
  },
  {
    key: '08',
    value: '8',
  },
  {
    key: '09',
    value: '9',
  },
  {
    key: '10',
    value: '10',
  },
  {
    key: '11',
    value: '11',
  },
  {
    key: '12',
    value: '12',
  },
];

const MINUTESDETAILS = [
  {
    key: '00',
    value: '0',
  },
  {
    key: '05',
    value: '5',
  },
  {
    key: '10',
    value: '10',
  },
  {
    key: '15',
    value: '15',
  },
  {
    key: '20',
    value: '20',
  },
  {
    key: '25',
    value: '25',
  },
  {
    key: '30',
    value: '30',
  },
  {
    key: '35',
    value: '35',
  },
  {
    key: '40',
    value: '40',
  },
  {
    key: '45',
    value: '45',
  },
  {
    key: '50',
    value: '50',
  },
  {
    key: '55',
    value: '55',
  },
];

const NOONDETAILS = [
  {
    key: 'AM',
    value: 'am',
  },
  {
    key: 'PM',
    value: 'pm',
  },
];

const WEEKDETAIILS = [
  {
    key: '1st',
    value: '1',
  },
  {
    key: '2nd',
    value: '2',
  },
  {
    key: '3rd',
    value: '3',
  },
  {
    key: '4th',
    value: '4',
  },
];

const BACKUPDETAILS = {
  transactionType: 'backup',
  emaiId: 'vigneshraj.asokan@sea.live',
};

const POPOVERTITLE = {
  SUCCESSTITLE: 'View Backup - Success Data',
  FAILEDTITLE: 'View Backup - Failed Data',
  RUNNINGTITLE: 'View Backup - Running Data',
};

export {
  COLUMNHEADER,
  EVERYDETAILS,
  HOURDETAILS,
  MINUTESDETAILS,
  NOONDETAILS,
  WEEKDETAIILS,
  BACKUPDETAILS,
  POPOVERTITLE,
};
