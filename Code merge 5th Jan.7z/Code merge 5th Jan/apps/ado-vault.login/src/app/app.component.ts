import { UserService } from '@ado-bcp-ui/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { ChangeDetectorRef, Component } from '@angular/core';
import { of } from 'rxjs';

@Component({
  selector: 'ado-bcp-ui-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'ado-vault.login';
  mobileQuery: MediaQueryList;
  isAuthenticated?:boolean=false;
  loading=true;
  private _mobileQueryListener: () => void;
  constructor(
    changeDetectorRef: ChangeDetectorRef,media: MediaMatcher,
    private userService:UserService
  ) {
    this.mobileQuery = media.matchMedia('(max-width: 767px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
    of(
      this.userService.isAuthenticated.subscribe((data:boolean) => {
        this.isAuthenticated = data;
        this.loading=false;
      })
    );


  }}