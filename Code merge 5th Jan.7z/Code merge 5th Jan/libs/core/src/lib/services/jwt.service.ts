/* eslint-disable @typescript-eslint/ban-types */
import { Injectable } from '@angular/core';
import { IUser } from '../model/header.model';

@Injectable()
export class JwtService {
  getToken(): String {
    return window.localStorage['jwtToken'];
  }

  saveToken(token: String) {
    window.localStorage['jwtToken'] = token;
  }

  destroyToken() {
    window.localStorage.removeItem('jwtToken');
    window.localStorage.clear();
  }
  getUser() {
    let userDetails: IUser = {
      name: '',
      email: '',
      token: '',
      permissions: [],
      username: '',
    };
    if (window.localStorage['userDetails']) {
      userDetails = JSON.parse(window.localStorage['userDetails']);
    }
    return userDetails;
  }

  saveUser(user: any) {
    window.localStorage['userDetails'] = JSON.stringify(user);
  }

  destroyUser() {
    window.localStorage.removeItem('userDetails');
  }
}
