import { PageName, PermissionsList, UserService } from '@ado-bcp-ui/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { Component, ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
})
export class SidebarComponent {
  sideMenuName :string;
  panelOpenState = false;
  mobileQuery: MediaQueryList;
  permissionList = PermissionsList;
  pageName = PageName;
  private _mobileQueryListener: () => void;

  constructor(
    changeDetectorRef: ChangeDetectorRef,
    media: MediaMatcher,
    private userService: UserService
  ) {
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
    this.sideMenuName = PageName.DASHBOARD;
  }

  // To get the read and write permissions for page
  readWritePermissions(pagename: string[]) {
    const permission: string[] =
      this.userService.getPageRolePermissions(pagename);
    return permission.length > 0 ? true : false;
  }
}
