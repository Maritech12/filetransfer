import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'convertToBlockSizePipe',
})
export class ConvertToBlockSizePipe implements PipeTransform {
  transform(value: string, lastUnderScore: number) {
    let splitDetails: any;
    if (lastUnderScore == 0) {
      if (value != '' && value != null) {
        let index = value.lastIndexOf('_');
        splitDetails = value.substring(0, index);
      } else splitDetails = '';
    } else {
      if (value != '' && value != null) {
        splitDetails = value.split('_');
        splitDetails = parseInt(splitDetails[splitDetails.length - 1]) / 1024;
        splitDetails = Math.round(splitDetails * 100) / 100;
      } else splitDetails = '';
    }
    return splitDetails;
  }
}
