import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { TableComponent } from './table/table.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatBadgeModule } from '@angular/material/badge';
import { MatCardModule } from '@angular/material/card';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { PopupLayoutComponent } from './popup-layout/popup-layout.component';
import { MatChipsModule } from '@angular/material/chips';
import { MatButtonModule } from '@angular/material/button';
import { MatNativeDateModule, MatRippleModule } from '@angular/material/core';
import { MatFormField, MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { TileComponent } from './tile/tile.component';
import { NotificationComponent } from './notification/notification.component';
import { UserComponent } from './user/user.component';
import { ApiService, JwtService } from '@ado-bcp-ui/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { DaysComponent } from './days/days.component';
import { TimeComponent } from './time/time.component';
import { WeekComponent } from './week/week.component';
import { PopOverComponent } from './pop-over/pop-over.component';
import { ModelPopupComponent } from './model-popup/model-popup.component';
import { ButtonComponent } from './controls/button/button.component';
import { DropdownComponent } from './controls/dropdown/dropdown.component';
import { MultiSelectComponent } from './controls/multi-select/multi-select.component';
import { SelectComponent } from './controls/select/select.component';
import { MatDialogModule } from '@angular/material/dialog';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { SearchbarComponent } from './controls/searchbar/searchbar.component';
import { CustomfilterComponent } from './controls/customfilter/customfilter.component';
import { OverlayModule } from '@angular/cdk/overlay';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UnAuthorizedComponent } from './un-authorized/un-authorized.component';
import { LoaderComponent } from './loader/loader.component';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { MatPaginatorModule } from '@angular/material/paginator';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { ConvertToBlockSizePipe } from './table/convertToBlockSize.pipe';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    MatIconModule,
    MatSidenavModule,
    MatListModule,
    MatToolbarModule,
    MatCardModule,
    MatMenuModule,
    MatExpansionModule,
    MatBadgeModule,
    MatTabsModule,
    MatTooltipModule,
    MatTableModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatRippleModule,
    MatChipsModule,
    HttpClientModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatDialogModule,
    MatGridListModule,
    MatCheckboxModule,
    OverlayModule,
    MatProgressBarModule,
    MatButtonToggleModule,
    MatSelectModule,
    MatCheckboxModule,
    FormsModule,
    FormsModule,
    ReactiveFormsModule,
    MatProgressSpinnerModule,
    MatPaginatorModule ,
    MatSnackBarModule,
    MatNativeDateModule,
    MatDatepickerModule,
  ],
  declarations: [
    TableComponent,
    PopupLayoutComponent,
    TileComponent,
    NotificationComponent,
    UserComponent,
    DropdownComponent,
    MultiSelectComponent,
    SelectComponent,
    ButtonComponent,
    DaysComponent,
    TimeComponent,
    WeekComponent,
    PopOverComponent,
    ModelPopupComponent,
    SearchbarComponent,
    CustomfilterComponent,
    UnAuthorizedComponent,
    LoaderComponent,
    ConvertToBlockSizePipe,
  ],
  exports: [
    TableComponent,
    PopupLayoutComponent,
    TileComponent,
    NotificationComponent,
    UserComponent,
    DropdownComponent,
    MultiSelectComponent,
    SelectComponent,
    ButtonComponent,
    DaysComponent,
    TimeComponent,
    WeekComponent,
    PopOverComponent,
    ModelPopupComponent,
    SearchbarComponent,
    CustomfilterComponent,
    LoaderComponent,
  ],
  providers: [ApiService, JwtService,DatePipe],
})
export class SharedComponentModule {}
