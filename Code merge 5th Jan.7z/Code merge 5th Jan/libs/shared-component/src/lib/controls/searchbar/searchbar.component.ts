import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-searchbar',
  templateUrl: './searchbar.component.html',
  styleUrls: ['./searchbar.component.scss'],
})
export class SearchbarComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
