import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'ado-bcp-ui-datepicker',
  templateUrl: './datepicker.component.html',
  styleUrls: ['./datepicker.component.scss'],
  
})
export class DatepickerComponent implements OnInit {
  public modeselect = 'Select';
  constructor() {}


  ngOnInit(): void {}
}
