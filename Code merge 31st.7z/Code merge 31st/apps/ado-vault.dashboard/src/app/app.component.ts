import { Component } from '@angular/core';
import { ScreenId } from './constants/dashboard-constant';

@Component({
  selector: 'ado-bcp-ui-root',
  template: '',
})
export class AppComponent {
  show: any;
  constructor() {
    this.show = ScreenId.WELCOME_SCREEN;
  }
}
