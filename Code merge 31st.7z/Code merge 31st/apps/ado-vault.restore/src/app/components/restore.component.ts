import {
  IProjects,
  IReadWriteAccess,
  IRestoreModel,
  IPeriod,
  SharedService,
  UserService,
  PermissionsList,
} from '@ado-bcp-ui/core';
import { ModelPopupComponent } from '@ado-bcp-ui/shared-component';
import { MediaMatcher } from '@angular/cdk/layout';
import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import {
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
  MatSnackBar,
} from '@angular/material/snack-bar';
import {
  COLUMNSHEADERDETAILS,
  COLUMNSSUBHEADER,
  ERRORCLASS,
  PERIODDETAILS,
  RESTOREDETAILS,
} from '../constants/restore-constant';

@Component({
  selector: 'ado-bcp-ui-restore',
  templateUrl: './restore.component.html',
  styleUrls: ['./restore.component.scss'],
})
export class RestoreComponent implements OnInit, OnDestroy {
  private _mobileQueryListener: () => void;
  mobileQuery: MediaQueryList;
  columnsHeaderDetails = COLUMNSHEADERDETAILS;
  columnsSubHeaderDetails = COLUMNSSUBHEADER;
  projectDetails: IProjects[] = [
    {
      projectid: '',
      projectname: '',
      organizationname: '',
      criticality: '',
      isative: 0,
      entitySettingsDetails: [],
      entityTransactionDetails: [],
    },
  ];

  restorePermission: IReadWriteAccess = {
    read: false,
    write: false,
  };

  restoreModel: IRestoreModel = {
    transactionType: '',
    isscheduled: 0,
    ReportingPeriod: 0,
    projectid: 0,
    userid: 0,
    userDetails: [],
  };

  periodDetails: IPeriod[] = PERIODDETAILS;
  onScheduleDetails: IRestoreModel[] = [];
  onDemandDetails: IRestoreModel[] = [];
  popOverDetails = [];
  actionViewDetails = {};
  loading: boolean;
  popOverTitle!: string;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  title!: string;
  createTitle!: string;

  constructor(
    private dialog: MatDialog,
    changeDetectorRef: ChangeDetectorRef,
    media: MediaMatcher,
    private sharedService: SharedService,
    private userService: UserService,
    private _snackBar: MatSnackBar
  ) {
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
    this.loading = false;
    //To Check the Restore Write Permissions---Start
    this.userService
      .getPagePermissions(PermissionsList.RESTORE_WRITE)
      .subscribe({
        next: (permissionResponse) => {
          if (permissionResponse.length > 0) {
            this.restorePermission.write = permissionResponse[0].write;
          }
        },
      });

    //To Check the Restore Write Permissions---End
  }

  ngOnInit(): void {
    this.title = RESTOREDETAILS.title;
    /*
     * To get the User Details and Project Details Information.
     */
    this.loading = true;
    this.getUserDetail().then((userDetails) => {
      /*
       * To get the Project Details Information.
       */
      this.getProject(userDetails);
    });

    /*
     * To get the OnDemand Restore and Schedule Details Information.
     */
    this.sharedService.dashBoardOnDemandSubject.subscribe({
      next: (onDemandResponse) => {
        this.onDemandDetails = onDemandResponse;
      },
    });
    this.sharedService.dashboardOnScheduleSubject.subscribe({
      next: (scheduleResponse) => {
        this.onScheduleDetails = scheduleResponse;
      },
    });
  }

  /*
   * This is a Description of the Destory
   */
  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }

  /*
   * To open the Model Popup Window.
   */
  openDialog() {
    this.dialog.open(ModelPopupComponent, {
      disableClose: true,
      width: '400px',
      data: { title: this.title },
    });
  }

  closeDialog() {
    this.dialog.closeAll();
  }

  /*
   * Select the Project Details Value.
   */
  selectProject(projectid: string) {
    this.restoreModel.projectid = projectid == '0' ? 0 : parseInt(projectid);
    this.getOnDemandRestore();
  }

  /*
   * Select the Period Details Value.
   */
  selectPeriod(period: string) {
    this.restoreModel.ReportingPeriod = period == '1' ? 1 : parseInt(period);
    this.getOnDemandRestore();
  }

  /*
   * To get the Project Details Information.
   * @param This is the organizationName Parameter
   */
  getProject(userDetails: any) {
    this.sharedService
      //.getProjectDetails(userDetails['companyModels'][0].companyname)
      .getProjectDetails('RestoreTest')
      .subscribe({
        next: (projectResponse: IProjects[]) => {
          if (projectResponse.length > 0) {
            this.projectDetails = projectResponse;
            this.loading = false;
          }
        },
        error: (errorResponse) => {
          this.openSnackBar(errorResponse, 0);
          this.loading = false;
        },
      });
  }

  /*
   * To get the User Details Information.
   * @param This is the User EmailId Parameter
   */
  getUserDetail() {
    return new Promise<void>((resolve) => {
      const UserDetails = this.userService.getCurrentUserDetails();
      this.sharedService.getUserDetailByEmailId(UserDetails.email).subscribe({
        next: (userResponse) => {
          if (userResponse != null) {
            this.restoreModel.userDetails = userResponse.userModel;
            this.restoreModel.userid = userResponse.userModel.userid;
            /*
             * Get the OnDemand Restore Details Information.
             */
            this.getOnDemandRestore();
            resolve(userResponse);
          }
        },
        error: (errorResponse) => {
          this.openSnackBar(errorResponse, 0);
          this.loading = false;
        },
      });
    });
  }

  /*
   * To get OnDemandRestore and Schedule Details Value.
   */
  getOnDemandRestore() {
    this.restoreModel.transactionType = RESTOREDETAILS.transactionType;
    this.restoreModel.isscheduled = 0;
    this.onDemandDetails = [];
    this.loading = true;
    this.sharedService.getDashBoardsTableDetails(this.restoreModel).subscribe({
      next: (onDemandResponse: IRestoreModel[]) => {
        if (onDemandResponse.length != 0) {
          this.onDemandDetails = onDemandResponse;
        }
        this.loading = false;
      },
      error: (errorResponse) => {
        this.openSnackBar(errorResponse, 0);
        this.loading = false;
      },
    });

    /*
     * To get the OnDemandSchedule Details Value.
     */
    this.restoreModel.isscheduled = 1;
    this.onScheduleDetails = [];
    this.loading = true;
    this.sharedService.getDashBoardsTableDetails(this.restoreModel).subscribe({
      next: (onScheduleResponse: IRestoreModel[]) => {
        if (onScheduleResponse.length != 0) {
          this.onScheduleDetails = onScheduleResponse;
        }
        this.loading = false;
      },
      error: (errorResponse) => {
        this.openSnackBar(errorResponse, 0);
        this.loading = false;
      },
    });
  }

  /*
   * To get the Action Details Value.
   */
  actionView(action: any) {
    this.createTitle = RESTOREDETAILS.title;
    this.sharedService.getLogDetails(action.entityTransactionId).subscribe({
      next: (actionResponse) => {
        if (actionResponse != '') {
          this.popOverDetails = actionResponse;
        }
      },
    });
  }

  /*
   * To Show the Message Content. success, danger, warning, info
   */
  openSnackBar(message: string, erroCode: number) {
    let className = '';
    switch (erroCode) {
      case 0:
        className = ERRORCLASS.SNACKBARWARNING;
        break;
      case 1:
        className = ERRORCLASS.SNACKBARSUCCESS;
        break;
      case 2:
        className = ERRORCLASS.SNACKBARDANGER;
        break;
      case 3:
        className = ERRORCLASS.SNACKBARINFO;
        break;
    }
    this._snackBar.open(message, '', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 3000,
      panelClass: [className],
    });
  }
}
