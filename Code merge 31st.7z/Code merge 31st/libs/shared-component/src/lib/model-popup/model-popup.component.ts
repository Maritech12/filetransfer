import {
  CONSTANT,
  NOON,
  IBackupModel,
  ICreateOnDemandBackup,
  ICreateOnScheduleBackup,
  IEntity,
  IEvery,
  IHour,
  IMinute,
  INoon,
  IProjects,
  IRepository,
  IRepositoryDetails,
  ISubEntity,
  IWeek,
  SharedService,
  UserService,
  IRestoreBlob,
  ICreateOnDemandRestore,
  ICreateOnScheduleRestore,
} from '@ado-bcp-ui/core';
import {
  Component,
  EventEmitter,
  Inject,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { DefaultStyleDirective } from '@angular/flex-layout';
import { MatCheckbox } from '@angular/material/checkbox';
import { MatOption } from '@angular/material/core';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSelect } from '@angular/material/select';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import {
  BACKUPDETAILS,
  EVERYDETAILS,
  HOURDETAILS,
  MINUTESDETAILS,
  NOONDETAILS,
  WEEKDETAIILS,
  DAYS,
  ERRORCLASS,
} from '../constants/sharedConstant';
@Component({
  selector: 'ado-bcp-ui-model-popup',
  templateUrl: './model-popup.component.html',
  styleUrls: ['./model-popup.component.scss'],
})
export class ModelPopupComponent implements OnInit {
  projectDetails: IProjects[] = [
    {
      projectid: '',
      projectname: '',
      organizationname: '',
      criticality: '',
      isative: 0,
      entitySettingsDetails: [],
      entityTransactionDetails: [],
    },
  ];

  entityDetails: IEntity[] = [
    {
      id: 0,
      name: '',
    },
  ];

  backupModel: IBackupModel = {
    transactionType: '',
    isscheduled: 0,
    ReportingPeriod: 0,
    projectid: 0,
    userid: 0,
    userDetails: [],
  };

  modelPopup: any = {
    organizationName: '',
    projectName: 'Select',
    entity: '',
    repoId: '',
    subEntityId: '',
    scheduler: '',
    blobs: [],
    cronExpression: {
      every: 'Daily',
      sec: 0,
      minutes: 0,
      hours: 0,
      dayOfMonth: '?',
      month: '*',
      dofWeek: '*',
      year: '*',
      days: '*',
      noon: '',
    },
  };
  onDemandBackup: ICreateOnDemandBackup = {
    repoIds: [],
    organization: '',
    project: '',
    subEntities: [],
  };
  onScheduleBackup: ICreateOnScheduleBackup = {
    repoIds: [],
    organization: '',
    project: '',
    cronExpression: '',
    subEntities: [],
  };
  onDemandRestore: ICreateOnDemandRestore = {
    repositories: [],
    organization: '',
    project: '',
    blobs: [],
    subentities: [],
  };
  onScheduleRestore: ICreateOnScheduleRestore = {
    repositories: [],
    organization: '',
    project: '',
    blobs: [],
    subentities: [],
    cronExpression: '',
  };
  repository: IRepository = {
    organization: '',
    project: '',
  };
  restoreBlob: IRestoreBlob = {
    projectName: '',
    entityName: '',
    entities: [],
    subEntities: [],
    date: '',
  };
  everyDetails: IEvery[] = EVERYDETAILS;
  hourDetails: IHour[] = HOURDETAILS;
  minuteDetails: IMinute[] = MINUTESDETAILS;
  noonDetails: INoon[] = NOONDETAILS;
  weekDetails: IWeek[] = WEEKDETAIILS;
  subEntityDetails!: ISubEntity[];
  repositoryDetails!: IRepositoryDetails[];
  onDemandBackupScheduleDetails = [];
  daysDetails: any = [];
  isCheckedSchedule: boolean = false;
  selectRepository: boolean = false;
  selecteSubEntity: boolean = false;
  selectBlobs: boolean = false;
  scheduledPopup: boolean = true;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  actualTime!: number;
  events: string[] = [];
  //Restore
  BlobRestoreDetails: any;
  backupDateDetails: any;
  multiDays: any = {
    selected: false,
  };

  @ViewChild('multiSelectRepository') public multiSelectRepository!: MatSelect;
  @ViewChild('multiSelectSubEntity') multiSelectSubEntity!: MatSelect;
  @ViewChild('multiSelectBlobs') multiSelectBlobs!: MatSelect;
  @ViewChild('myCheckbox') private myCheckbox!: MatCheckbox;
  @ViewChild('closebutton') closebutton!: any;
  loading: boolean = false;
  dialogTitle!: string;

  @Output() openDialog: EventEmitter<any> = new EventEmitter();
  constructor(
    private sharedService: SharedService,
    private userService: UserService,
    private _snackBar: MatSnackBar,
    public dialogRef: MatDialogRef<ModelPopupComponent>,
    @Inject(MAT_DIALOG_DATA) public createTitle: { title: string }
  ) {}
  ngOnInit(): void {
    this.multiDays = DAYS;
    this.loading = true;
    /*
     * To get the User Details Information.
     */
    this.getUserDetail().then((userDetails) => {
      /*
       * To get the Project Details Information.
       */
      this.getProject(userDetails);
    });

    /*
     * To get the Entity Details Information.
     */
    this.getEntity();

    /*
     * To get the Sub Entity Details Information.
     */
    this.getSubEntity();
  }

  /*
   * To get the Project Details Information.
   * @param This is the OrganizationName Parameter
   */
  getProject(userDetails: any) {
    this.modelPopup.organizationName = 'RestoreTest';
    //this.modelPopup.organizationName =userDetails['companyModels'][0].companyname;
    this.sharedService
      .getProjectDetails(this.modelPopup.organizationName)
      .subscribe({
        next: (projectResponse) => {
          this.projectDetails = projectResponse;
          this.loading = false;
        },
        error: (errorResponse) => {
          /*
           * To Show the Error Content.
           */
          this.openSnackBar(errorResponse, 0);
          this.loading = false;
        },
      });
  }

  getEntity() {
    /*
     * To get the Entity Details Information.
     */
    this.sharedService.getEntityDetails().subscribe({
      next: (entityResponse: IEntity[]) => {
        this.entityDetails = entityResponse;
      },
    });
  }

  getSubEntity() {
    /*
     * To get the Sub Entity Details Information.
     */
    this.sharedService.getSubEntityDetails().subscribe({
      next: (subEntityResponse: ISubEntity[]) => {
        this.subEntityDetails = subEntityResponse;
      },
    });
  }

  /*
   * To Select the Project Details Information.
   * @param This is the ProjectName Parameter
   */
  selectProject(projectName: string) {
    this.clear(CONSTANT.PROJECT);
    if (CONSTANT.PROJECT == parseInt(projectName)) this.clear(CONSTANT.PROJECT);
    else {
      this.modelPopup.projectName = projectName;
      this.repository.project = this.modelPopup.projectName;
      this.repository.organization = this.modelPopup.organizationName;
      this.getRepository();
    }
  }

  /*
   * To select the Entity Details Information.
   */
  selectEntity(entity: any) {
    if (CONSTANT.ENTITY == entity.id) this.clear(CONSTANT.ENTITY);
    else {
      this.modelPopup.entity = entity.id;
      //Restore
      this.restoreBlob.entityName = entity.name;
    }
  }

  /*
   * To get the Repository Details Information.
   * @param This is the OrganizationName and ProjectName Parameter
   */
  getRepository() {
    this.sharedService.getRepositoryDetails(this.repository).subscribe({
      next: (repositoryResponse) => {
        this.repositoryDetails = repositoryResponse.repositories;
      },
    });
  }

  /*
   * To select All Repo and SubEntity Details.
   */
  SelectAll(selectFlag: boolean) {
    if (selectFlag) {
      if (this.selectRepository) {
        this.multiSelectRepository.options.forEach((item: MatOption) =>
          item.select()
        );
      } else {
        this.multiSelectRepository.options.forEach((item: MatOption) =>
          item.deselect()
        );
      }
      this.modelPopup.repoId = this.multiSelectRepository.value;
    } else {
      if (this.selecteSubEntity) {
        this.multiSelectSubEntity.options.forEach((item: MatOption) =>
          item.select()
        );
      } else {
        this.multiSelectSubEntity.options.forEach((item: MatOption) =>
          item.deselect()
        );
      }
      this.modelPopup.subEntityId = this.multiSelectSubEntity.value;
    }
  }

  /*
   * To click the Repo and SubEntity Values.
   */
  optionClick(selectFlag: boolean) {
    if (selectFlag) {
      let status = true;
      this.multiSelectRepository.options.forEach((item: MatOption) => {
        if (!item.selected) {
          status = false;
        }
      });
      this.selectRepository = status;
      this.modelPopup.repoId = this.multiSelectRepository.value;
    } else {
      let status = true;
      this.multiSelectSubEntity.options.forEach((item: MatOption) => {
        if (!item.selected) {
          status = false;
        }
      });
      this.selecteSubEntity = status;
      this.modelPopup.subEntityId = this.multiSelectSubEntity.value;
    }
  }

  /*
   * This is a description of clear the values
   */
  clearAll(select: MatSelect, clearFlag: boolean) {
    if (clearFlag) {
      this.selectRepository = false;
      this.modelPopup.repoId = [];
      select.value = [];
    } else {
      this.selecteSubEntity = false;
      this.modelPopup.subEntityId = [];
      select.value = [];
    }
  }

  /*
   * Here we can Select Repository and SubEntity Value.
   */
  ok(select: any, okFlag: boolean) {
    if (okFlag) {
      if (this.modelPopup.repoId.length > 0 && okFlag) select.close();
      else this.modelPopup.repoId = this.modelPopup.repoId;
    } else {
      if (this.modelPopup.subEntityId.length > 0) select.close();
      else this.modelPopup.subEntityId = this.modelPopup.subEntityId;
    }
  }

  /*
   * This is a description of the cancel
   */
  cancel() {}

  /*
   *To Select the Schedule Popup.
   */
  schedulePopup() {
    this.scheduledPopup = !this.scheduledPopup;
    if (!this.scheduledPopup) this.clear(2);
  }

  /*
   * To Select the every value.
   */
  selectEvery(every: string) {
    this.clear(2);
    this.modelPopup.cronExpression.every = every;
  }

  /*
   * To Select the hour value.
   */
  selectHour(hour: string) {
    this.modelPopup.cronExpression.hours = hour;
  }

  /*
   * To Select the minute value.
   */
  selectMinute(minute: string) {
    this.modelPopup.cronExpression.minutes = minute;
  }

  /*
   * To Select the Week value.
   */
  selectWeek(week: string) {
    this.modelPopup.cronExpression.dofWeek = week;
  }

  /*
   *To Select the noon value.
   */
  selectNoon(noon: string) {
    this.actualTime = parseInt(this.modelPopup.cronExpression.hours);
    if (noon == NOON.PM) {
      if (this.actualTime == 12) this.actualTime = this.actualTime;
      else this.actualTime = this.actualTime + 12;
    } else {
      if (this.actualTime == 12) this.actualTime = 0;
      else this.actualTime = this.actualTime;
    }
  }

  /*
   *To Select the days value.
   */

  selectDays = (days: any): void => {
    days.selected = !days.selected;
    this.modelPopup.cronExpression.days = [];
    //Here we can selected the days value.
    if (days.selected === true && this.modelPopup.cronExpression.every == 'M') {
      this.daysDetails.push(days.value);
      //Here We can select only one day in the month
      if (this.daysDetails.length > 1) {
        this.openSnackBar(BACKUPDETAILS.daysMessage, 0);
        let index = this.multiDays.findIndex(
          (x: any) => x.value === days.value
        );
        this.multiDays[index].selected = false;
        this.daysDetails.splice(
          this.daysDetails.findIndex(
            (x: any) => x == this.multiDays[index].value
          ),
          1
        );
        this.modelPopup.cronExpression.days = this.daysDetails;
      } else {
        let i = this.multiDays.findIndex((x: any) => x.value === days.value);
        this.multiDays[i].selected = true;
        this.modelPopup.cronExpression.days = this.daysDetails
          .map((e: string) => e.replace(/\s/g, ''))
          .join(',');
      }
    }
    // We can select Multiple days value.
    else if (
      days.selected === true &&
      this.modelPopup.cronExpression.every == 'W'
    ) {
      this.daysDetails.push(days.value);
      let i = this.multiDays.findIndex((x: any) => x.value === days.value);
      this.multiDays[i].selected = true;
      this.modelPopup.cronExpression.days = this.daysDetails
        .map((e: string) => e.replace(/\s/g, ''))
        .join(',');
    }

    // Here Unchecked the days value Of Month and Week.
    else {
      let i = this.multiDays.findIndex((x: any) => x.value === days.value);
      this.multiDays[i].selected = false;
      this.daysDetails.splice(
        this.daysDetails.findIndex((x: any) => x == this.multiDays[i].value),
        1
      );
      this.modelPopup.cronExpression.days = this.daysDetails;
    }
  };

  ngOnChanges() {}

  /*
   *To select the Project value.
   */
  createProject(title: string) {
    switch (title) {
      case 'Backup':
        this.createOnDemandBackup();
        break;
      case 'Restore':
        this.createOnDemandBackupRestore();
        break;
    }
  }

  /*
   * Create OnDemandBackup and OnScheduleBackup Information.
   * @param This is the organizationName,projectName,entity and repoId parameter
   */
  createOnDemandBackup() {
    /*
     * To Create the OnDemandBackup Information.
     */
    if (!this.isCheckedSchedule) {
      this.onDemandBackup.organization = this.modelPopup.organizationName;
      this.onDemandBackup.subEntities = this.modelPopup.subEntityId;
      this.onDemandBackup.project = this.modelPopup.projectName;
      this.onDemandBackup.repoIds = this.modelPopup.repoId;
      this.loading = true;
      this.backupModel.transactionType = BACKUPDETAILS.backupTransactionType;
      this.sharedService.createOnDemandBackup(this.onDemandBackup).subscribe({
        next: (onDemandResponse) => {
          if (onDemandResponse.statusCode == 200) {
            this.onDemandBackupScheduleDetails = onDemandResponse.result;
            this.getOnDemandBackupRestore();
            this.loading = false;
            /*
             * To Show the Message Content.
             */
            this.openSnackBar(onDemandResponse.result, 1);
            this.dialogRef.close();
          } else {
            this.openSnackBar(onDemandResponse.message, 0);
            this.dialogRef.close();
          }
        },
        error: (errorResponse) => {
          /*
           * To Show the Error Content.
           */
          this.openSnackBar(errorResponse, 0);
          this.dialogRef.close();
        },
      });
    } else {
      /*
       * Cron Expression for Daily,Weekly and Monthly.
       */
      this.modelPopup.cronExpression.hours = this.actualTime.toString();
      if (this.modelPopup.cronExpression.every == 'D') {
        this.onScheduleBackup.cronExpression =
          +this.modelPopup.cronExpression.sec +
          ' ' +
          this.modelPopup.cronExpression.minutes +
          ' ' +
          this.modelPopup.cronExpression.hours +
          ' ' +
          this.modelPopup.cronExpression.dayOfMonth +
          ' ' +
          this.modelPopup.cronExpression.month +
          ' ' +
          this.modelPopup.cronExpression.dofWeek +
          ' ' +
          this.modelPopup.cronExpression.year;
      } else if (this.modelPopup.cronExpression.every == 'M') {
        this.modelPopup.cronExpression.days =
          this.modelPopup.cronExpression.days +
          '#' +
          this.modelPopup.cronExpression.dofWeek;

        this.onScheduleBackup.cronExpression =
          +this.modelPopup.cronExpression.sec +
          ' ' +
          this.modelPopup.cronExpression.minutes +
          ' ' +
          this.modelPopup.cronExpression.hours +
          ' ' +
          this.modelPopup.cronExpression.dayOfMonth +
          ' ' +
          this.modelPopup.cronExpression.month +
          ' ' +
          this.modelPopup.cronExpression.days +
          ' ' +
          this.modelPopup.cronExpression.year;
      } else if (this.modelPopup.cronExpression.every == 'W') {
        this.onScheduleBackup.cronExpression =
          +this.modelPopup.cronExpression.sec +
          ' ' +
          this.modelPopup.cronExpression.minutes +
          ' ' +
          this.modelPopup.cronExpression.hours +
          ' ' +
          this.modelPopup.cronExpression.dayOfMonth +
          ' ' +
          this.modelPopup.cronExpression.month +
          ' ' +
          this.modelPopup.cronExpression.days +
          ' ' +
          this.modelPopup.cronExpression.year;
      }
      /*
       * End
       */

      /*
       * To Create the OnScheduleBackup Information.
       */
      this.onScheduleBackup.organization = this.modelPopup.organizationName;
      this.onScheduleBackup.project = this.modelPopup.projectName;
      this.onScheduleBackup.repoIds = this.modelPopup.repoId;
      this.onScheduleBackup.subEntities = this.modelPopup.subEntityId;
      this.backupModel.transactionType = BACKUPDETAILS.backupTransactionType;
      this.loading = true;

      this.sharedService
        .createOnScheduleBackup(this.onScheduleBackup)
        .subscribe({
          next: (onScheduleResponse) => {
            if (onScheduleResponse.statusCode == 200) {
              this.onDemandBackupScheduleDetails = onScheduleResponse.result;
              this.loading = false;
              /*
               * To Show the Message Content.
               */
              this.openSnackBar(onScheduleResponse.result, 1);
              this.getOnDemandBackupRestore();
              this.dialogRef.close();
            } else {
              this.openSnackBar(onScheduleResponse.message, 0);
              this.dialogRef.close();
            }
          },
          error: (errorResponse) => {
            /*
             * To Show the Error Content.
             */
            this.openSnackBar(errorResponse, 0);
            this.dialogRef.close();
          },
        });
    }
  }

  /*
   * To clear the Model Popup value.
   */
  clear(clear: number) {
    switch (clear) {
      case 0:
        this.modelPopup.projectName = CONSTANT.SELECT;
        this.modelPopup.entity = CONSTANT.SINGLEQUOTES;
        this.modelPopup.repoId = CONSTANT.SINGLEQUOTES;
        this.modelPopup.subEntityId = CONSTANT.SINGLEQUOTES;
        this.modelPopup.cronExpression.every = CONSTANT.SELECT;
        this.modelPopup.cronExpression.sec = CONSTANT.NUMBER;
        this.modelPopup.cronExpression.minutes = CONSTANT.NUMBER;
        this.modelPopup.cronExpression.hours = CONSTANT.NUMBER;
        this.modelPopup.cronExpression.noon = CONSTANT.NUMBER;
        this.scheduledPopup = true;
        break;

      case 1:
        this.modelPopup.entity = CONSTANT.SINGLEQUOTES;
        this.modelPopup.repoId = CONSTANT.SINGLEQUOTES;
        this.modelPopup.subEntityId = CONSTANT.SINGLEQUOTES;
        this.modelPopup.cronExpression.every = CONSTANT.SELECT;
        this.modelPopup.cronExpression.sec = CONSTANT.NUMBER;
        this.modelPopup.cronExpression.minutes = CONSTANT.NUMBER;
        this.modelPopup.cronExpression.hours = CONSTANT.NUMBER;
        this.modelPopup.cronExpression.noon = CONSTANT.NUMBER;
        this.scheduledPopup = true;
        break;

      case 2:
        this.modelPopup.cronExpression.every = CONSTANT.EVERY;
        this.modelPopup.cronExpression.sec = CONSTANT.SEC;
        this.modelPopup.cronExpression.minutes = CONSTANT.MINUTES;
        this.modelPopup.cronExpression.hours = CONSTANT.HOURS;
        this.modelPopup.cronExpression.noon = CONSTANT.NOON;
        this.modelPopup.cronExpression.dayOfMonth = CONSTANT.DAYOFMONTH;
        this.modelPopup.cronExpression.month = CONSTANT.MONTH;
        this.modelPopup.cronExpression.dofWeek = CONSTANT.DOFWEEK;
        this.modelPopup.cronExpression.year = CONSTANT.YEAR;
        this.modelPopup.cronExpression.days = CONSTANT.DAYS;
        this.daysDetails = [];
        this.multiDays.forEach((item: any) => {
          item.selected = false;
        });
        break;
    }
  }

  /*
   * To get the User Details Information.
   * @param This is the User EmailId Parameter
   */
  getUserDetail() {
    return new Promise<void>((resolve) => {
      const UserDetails = this.userService.getCurrentUserDetails();
      this.sharedService.getUserDetailByEmailId(UserDetails.email).subscribe({
        next: (userResponse) => {
          if (userResponse) {
            this.backupModel.userid = userResponse.userModel.userid;
            resolve(userResponse);
          }
        },
        error: (errorResponse) => {
          /*
           * To Show the Error Content.
           */
          this.openSnackBar(errorResponse, 0);
          this.loading = false;
        },
      });
    });
  }

  /*
   * To get the OnDemand Backup and Details Information.
   * @param This is the TransactionType,userid,parameter
   */
  getOnDemandBackupRestore() {
    /*
     * To get the OnDemand Backup Information.
     */
    this.sharedService.getDashBoardsTableDetails(this.backupModel).subscribe({
      next: (onDemandResponse) => {
        if (onDemandResponse.length > 0) {
          this.sharedService.dashBoardOnDemandSubject.next(onDemandResponse);
        }
      },
      error: (errorResponse) => {
        /*
         * To Show the Error Content.
         */
        this.openSnackBar(errorResponse, 0);
        this.dialogRef.close();
      },
    });

    /*
     * To get the OnSchedule Backup Information.
     */
    this.backupModel.isscheduled = 1;
    this.sharedService.getDashBoardsTableDetails(this.backupModel).subscribe({
      next: (scheduleResponse) => {
        if (scheduleResponse.length > 0) {
          this.sharedService.dashboardOnScheduleSubject.next(scheduleResponse);
        }
        this.dialogRef.close();
      },
      error: (errorResponse) => {
        /*
         * To Show the Error Content.
         */
        this.openSnackBar(errorResponse, 0);
        this.dialogRef.close();
      },
    });
  }

  /*
   * To Show the Message Content.
   */

  openSnackBar(message: string, erroCode: number) {
    let className = '';
    switch (erroCode) {
      case 0:
        className = ERRORCLASS.SNACKBARWARNING;
        break;
      case 1:
        className = ERRORCLASS.SNACKBARSUCCESS;
        break;
      case 2:
        className = ERRORCLASS.SNACKBARDANGER;
        break;
      case 3:
        className = ERRORCLASS.SNACKBARINFO;
        break;
    }
    this._snackBar.open(message, '', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 3000,
      panelClass: [className],
    });
  }

  /*
   * To Select the Backup Date Information.
   */
  selectBackupDate(backupDate: any) {
    this.restoreBlob.date =
      backupDate.value?.getMonth() +
      1 +
      '-' +
      backupDate.value?.getDate() +
      '-' +
      backupDate.value?.getFullYear();

    this.getRestoreBlobs();
  }

  /*
   * To get the Blobs Information.
   * @param This is the EntityName,ProjectName,Entities,Date and SubEntities Parameter
   */
  getRestoreBlobs() {
    this.restoreBlob.projectName = this.modelPopup.projectName;
    this.restoreBlob.entities = this.modelPopup.repoId;
    this.restoreBlob.subEntities = this.modelPopup.subEntityId;

    this.loading = true;
    this.sharedService
      .getRestoreBlobsDetails(JSON.stringify(this.restoreBlob))
      .subscribe({
        next: (restoreBlobResponse) => {
          this.BlobRestoreDetails = restoreBlobResponse;
          this.loading = false;
        },
        error: (errorResponse) => {
          /*
           * To Show the Error Content.
           */
          this.openSnackBar(errorResponse, 0);
          this.dialogRef.close();
        },
      });
  }

  /*
   * To select All Bobs Details.
   */
  SelectAllBlobs() {
    if (this.selectBlobs) {
      this.multiSelectBlobs.options.forEach((item: MatOption) => item.select());
    } else {
      this.multiSelectBlobs.options.forEach((item: MatOption) =>
        item.deselect()
      );
    }
    this.modelPopup.blobs = this.multiSelectBlobs.value;
  }

  /*
   * To click the Repo and SubEntity Values.
   */
  optionClickBlobs() {
    let status = true;
    this.multiSelectBlobs.options.forEach((item: MatOption) => {
      if (!item.selected) {
        status = false;
      }
    });
    this.selectRepository = status;
    this.modelPopup.blobs = this.multiSelectBlobs.value;
  }
  /*
   * To clear all Blobs Values.
   */
  clearAllBlobs(select: MatSelect) {
    this.selectBlobs = false;
    this.modelPopup.blobs = [];
    select.value = [];
  }

  /*
   * Here we can Select Blobs.
   */
  okBlobs(select: any, okFlag: boolean) {
    if (okFlag) {
      if (this.onDemandRestore.blobs.length > 0 && okFlag) select.close();
      else this.modelPopup.blobs = this.onDemandRestore.blobs;
    }
  }

  /*
   * Create OnDemandBackup&Restore and OnScheduleBackup&Restore Information.
   * @param This is the OrganizationName,ProjectName,Repositories,Blobs,Entity and SubEntities Parameter
   */
  createOnDemandBackupRestore() {
    /*
     * To Create the onDemand Restore Information.
     */
    if (!this.isCheckedSchedule) {
      this.onDemandRestore.organization = this.modelPopup.organizationName;
      this.onDemandRestore.project = this.modelPopup.projectName;
      this.onDemandRestore.repositories = this.modelPopup.repoId;
      this.onDemandRestore.subentities = this.modelPopup.subEntityId;
      this.onDemandRestore.blobs = this.modelPopup.blobs;
      this.loading = true;
      this.backupModel.transactionType = BACKUPDETAILS.restoreTransactionType;
      this.sharedService
        //.createOnDemandRestore(JSON.stringify(this.onDemandRestore))
        .createOnDemandRestore(this.onDemandRestore)
        .subscribe({
          next: (onDemandRestoreResponse) => {
            if (onDemandRestoreResponse.statusCode == 200) {
              this.getOnDemandBackupRestore();
              this.loading = false;
              /*
               * To Show the Message Content.
               */
              this.openSnackBar(onDemandRestoreResponse.result, 1);
              this.dialogRef.close();
            } else {
              this.openSnackBar(onDemandRestoreResponse.message, 0);
              this.dialogRef.close();
            }
          },
          error: (errorResponse) => {
            /*
             * To Show the Error Content.
             */
            this.openSnackBar(errorResponse, 0);
            this.dialogRef.close();
          },
        });
    } else {
      /*
       * Cron Expression for Daily,Weekly and Monthly.
       */
      this.modelPopup.cronExpression.hours = this.actualTime.toString();
      this.backupModel.transactionType = BACKUPDETAILS.restoreTransactionType;
      if (this.modelPopup.cronExpression.every == 'D') {
        this.onScheduleRestore.cronExpression =
          +this.modelPopup.cronExpression.sec +
          ' ' +
          this.modelPopup.cronExpression.minutes +
          ' ' +
          this.modelPopup.cronExpression.hours +
          ' ' +
          this.modelPopup.cronExpression.dayOfMonth +
          ' ' +
          this.modelPopup.cronExpression.month +
          ' ' +
          this.modelPopup.cronExpression.dofWeek +
          ' ' +
          this.modelPopup.cronExpression.year;
      } else if (this.modelPopup.cronExpression.every == 'M') {
        this.modelPopup.cronExpression.days =
          this.modelPopup.cronExpression.days +
          '#' +
          this.modelPopup.cronExpression.dofWeek;

        this.onScheduleRestore.cronExpression =
          +this.modelPopup.cronExpression.sec +
          ' ' +
          this.modelPopup.cronExpression.minutes +
          ' ' +
          this.modelPopup.cronExpression.hours +
          ' ' +
          this.modelPopup.cronExpression.dayOfMonth +
          ' ' +
          this.modelPopup.cronExpression.month +
          ' ' +
          this.modelPopup.cronExpression.days +
          ' ' +
          this.modelPopup.cronExpression.year;
      } else if (this.modelPopup.cronExpression.every == 'W') {
        this.onScheduleRestore.cronExpression =
          +this.modelPopup.cronExpression.sec +
          ' ' +
          this.modelPopup.cronExpression.minutes +
          ' ' +
          this.modelPopup.cronExpression.hours +
          ' ' +
          this.modelPopup.cronExpression.dayOfMonth +
          ' ' +
          this.modelPopup.cronExpression.month +
          ' ' +
          this.modelPopup.cronExpression.days +
          ' ' +
          this.modelPopup.cronExpression.year;
      }
      /*
       * End
       */

      /*
       * To Create the OnSchedule Restore Information.
       */
      this.onScheduleRestore.organization = this.modelPopup.organizationName;
      this.onScheduleRestore.project = this.modelPopup.projectName;
      this.onScheduleRestore.repositories = this.modelPopup.repoId;
      this.onScheduleRestore.subentities = this.modelPopup.subEntityId;
      this.onScheduleRestore.blobs = this.modelPopup.blobs;
      this.loading = true;

      this.sharedService
        .createOnScheduleRestore(JSON.stringify(this.onScheduleRestore))
        .subscribe({
          next: (onScheduleRestoreResponse) => {
            if (onScheduleRestoreResponse.statusCode == 200) {
              this.loading = false;
              /*
               * To Show the Message Content.
               */
              this.openSnackBar(onScheduleRestoreResponse.result, 1);
              this.getOnDemandBackupRestore();
              this.dialogRef.close();
            } else {
              this.openSnackBar(onScheduleRestoreResponse.message, 0);
              this.dialogRef.close();
            }
          },
          error: (errorResponse) => {
            /*
             * To Show the Error Content.
             */
            this.openSnackBar(errorResponse, 0);
            this.dialogRef.close();
          },
        });
    }
  }
}
