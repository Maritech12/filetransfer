import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { utc } from 'moment';

@Component({
  selector: 'ado-bcp-ui-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss'],
})
export class TableComponent implements OnInit, OnChanges {
  @Input() from = '';
  @Input() tableDetails!: any;
  @Input() displayedColumnHeader: any;
  @Input() displayedColumnSubHeader: any;
  @Output() onChanged: EventEmitter<any> = new EventEmitter<any>();
  @Input() popOverDetails: any;
  @Input() popOverTitleDetails: any;
  @Input() loading: any;
  @Input() createTitle: any;

  dataSource = new MatTableDataSource(this.tableDetails);
  @ViewChild('paginator') paginator!: MatPaginator;
  @ViewChild('paginatorPageSize') paginatorPageSize!: MatPaginator;
  utc = utc;

  ngOnChanges(changes: SimpleChanges): void {
    this.dataSource = new MatTableDataSource(this.tableDetails);
    this.dataSource.paginator = this.paginator;
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
  ngOnInit() {
    this.dataSource = new MatTableDataSource(this.tableDetails);
  }
}
