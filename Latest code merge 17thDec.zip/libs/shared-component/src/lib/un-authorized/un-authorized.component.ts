import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-un-authorized',
  templateUrl: './un-authorized.component.html',
  styleUrls: ['./un-authorized.component.scss'],
})
export class UnAuthorizedComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
