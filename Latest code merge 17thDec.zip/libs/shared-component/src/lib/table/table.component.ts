import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss'],
})
export class TableComponent implements OnInit {
  @Input() from = '';
  @Input() tableSource: any;
  @Input() displayedColumnHeader: any;
  @Input() displayedColumnSubHeader: any;
  @Output() onChanged: EventEmitter<any> = new EventEmitter<any>();
  @Input() backupRestoreDetails: any;
  @Input() actionDetails: any;
  @Input() popOverTitleDetails: any;
  ngOnInit() {}
}
