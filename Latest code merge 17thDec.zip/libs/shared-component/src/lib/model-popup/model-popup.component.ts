import {
  EConstant,
  Enoon,
  IBackupModel,
  ICreateOnDemandBackup,
  ICreateOnScheduleBackup,
  IEntity,
  IEvery,
  IHour,
  IMinute,
  INoon,
  IProjects,
  IRepository,
  IRepositoryDetails,
  IRepoSubentity,
  IWeek,
  SharedService,
} from '@ado-bcp-ui/core';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatCheckbox } from '@angular/material/checkbox';
import { MatOption } from '@angular/material/core';
import { MatSelect } from '@angular/material/select';
import {
  BACKUPDETAILS,
  EVERYDETAILS,
  HOURDETAILS,
  MINUTESDETAILS,
  NOONDETAILS,
  WEEKDETAIILS,
} from '../constants/sharedConstant';

@Component({
  selector: 'ado-bcp-ui-model-popup',
  templateUrl: './model-popup.component.html',
  styleUrls: ['./model-popup.component.scss'],
})
export class ModelPopupComponent implements OnInit {
  projectDetails: IProjects[] = [
    {
      projectid: '',
      projectname: '',
      organizationname: '',
      criticality: '',
      isative: 0,
      entitySettingsDetails: [],
      entityTransactionDetails: [],
    },
  ];

  entityDetails: IEntity[] = [
    {
      id: 0,
      name: '',
    },
  ];

  backupModel: IBackupModel = {
    transactionType: '',
    isscheduled: 0,
    ReportingPeriod: 0,
    projectid: 0,
    userid: 0,
  };

  modelPopup: any = {
    organizationName: '',
    projectName: 'Select',
    entity: '',
    repoId: '',
    subEntityId: '',
    scheduler: '',
    cronExpression: {
      every: 'Daily',
      sec: 0,
      minutes: 0,
      hours: 0,
      dayOfMonth: '?',
      month: '*',
      dofWeek: '*',
      year: '*',
      days: '',
      noon: '',
    },
  };
  onDemandBackupPayload: ICreateOnDemandBackup = {
    repoIds: [],
    organizationName: '',
    projectName: '',
    subEntitiesName: [],
  };
  onScheduleBackupPayload: ICreateOnScheduleBackup = {
    repoIds: [],
    organizationName: '',
    projectName: '',
    cronExpression: '',
    subEntitiesName: [],
  };
  repositoryPayload: IRepository = {
    organizationName: '',
    projectName: '',
  };
  everyDetails: IEvery[] = EVERYDETAILS;
  hourDetails: IHour[] = HOURDETAILS;
  minuteDetails: IMinute[] = MINUTESDETAILS;
  noonDetails: INoon[] = NOONDETAILS;
  weekDetails: IWeek[] = WEEKDETAIILS;
  isCheckedSchedule: boolean = false;
  selectRepository: boolean = false;
  selecteSubEntity: boolean = false;
  scheduledPopup: boolean = true;
  subEntityDetails!: IRepoSubentity[];
  repositoryDetails!: IRepositoryDetails[];
  onDemandBackupScheduleDetails = [];
  daysDetails: string[] = [];
  actualTime!: number;
  @ViewChild('multiSelectRepository') public multiSelectRepository!: MatSelect;
  @ViewChild('multiSelectSubEntity') multiSelectSubEntity!: MatSelect;
  @ViewChild('myCheckbox') private myCheckbox!: MatCheckbox;

  constructor(private sharedService: SharedService) {}
  ngOnInit(): void {
    /*
     * This is a description of the User details value
     */
    this.getUserDetail();

    /*
     * This is a description of the Project details value
     */
    this.getProject();

    /*
     * This is a description of the Entity details value
     */
    this.getEntity();

    /*
     * This is a description of the Sub Entity Details value
     */
    this.getRepoSubentity();
  }

  /*
   * This is a description of the Project details value
   * @param This is the organizationname parameter
   */
  getProject() {
    this.modelPopup.organizationName = EConstant.organizationName;
    this.sharedService
      .getProjectDetails(this.modelPopup.organizationName)
      .subscribe((data) => {
        this.projectDetails = data;
      });
  }

  getEntity() {
    /*
     * This is a description of the Entity details value
     */
    this.sharedService.getEntityDetails().subscribe((data: IEntity[]) => {
      this.entityDetails = data;
    });
  }

  getRepoSubentity() {
    /*
     * This is a description of the Sub Entity details value
     */
    this.sharedService
      .getRepoSubentityDetails()
      .subscribe((data: IRepoSubentity[]) => {
        this.subEntityDetails = data;
      });
  }

  /*
   * This is a description of the Select Project value
   * @param This is the projectName parameter
   */
  selectProject(projectName: string) {
    this.clear(EConstant.project);
    if (EConstant.project == parseInt(projectName))
      this.clear(EConstant.project);
    else {
      this.modelPopup.projectName = projectName;
      this.repositoryPayload.projectName = this.modelPopup.projectName;
      this.repositoryPayload.organizationName = EConstant.organizationName;
      this.getRepository();
    }
  }

  /*
   * This is a description of select Entity values
   */
  selectEntity(entity: number) {
    if (EConstant.entity == entity) this.clear(EConstant.entity);
    else this.modelPopup.entity = entity;
  }

  /*
   * This is a description of Fetching the Repository Details
   * @param This is the organizationName and projectName parameter
   */
  getRepository() {
    this.sharedService
      .getRepositoryDetails(this.repositoryPayload)
      .subscribe((repo) => {
        this.repositoryDetails = repo.repositories;
      });
  }

  /*
   * This is a description of select All Repo and Subentity values
   */
  SelectAll(selectFlag: boolean) {
    if (selectFlag) {
      if (this.selectRepository) {
        this.multiSelectRepository.options.forEach((item: MatOption) =>
          item.select()
        );
      } else {
        this.multiSelectRepository.options.forEach((item: MatOption) =>
          item.deselect()
        );
      }
      this.modelPopup.repoId = this.multiSelectRepository.value;
    } else {
      if (this.selecteSubEntity) {
        this.multiSelectSubEntity.options.forEach((item: MatOption) =>
          item.select()
        );
      } else {
        this.multiSelectSubEntity.options.forEach((item: MatOption) =>
          item.deselect()
        );
      }
      this.modelPopup.subEntityId = this.multiSelectSubEntity.value;
    }
  }

  /*
   * This is a description of Repo and subEntity values
   */
  optionClick(selectFlag: boolean) {
    if (selectFlag) {
      let status = true;
      this.multiSelectRepository.options.forEach((item: MatOption) => {
        if (!item.selected) {
          status = false;
        }
      });
      this.selectRepository = status;
      this.modelPopup.repoId = this.multiSelectRepository.value;
    } else {
      let status = true;
      this.multiSelectSubEntity.options.forEach((item: MatOption) => {
        if (!item.selected) {
          status = false;
        }
      });
      this.selecteSubEntity = status;
      this.modelPopup.subEntityId = this.multiSelectSubEntity.value;
    }
  }

  /*
   * This is a description of clear the values
   */
  clearAll(select: MatSelect, clearFlag: boolean) {
    if (clearFlag) {
      this.selectRepository = false;
      this.modelPopup.repoId = [];
      select.value = [];
    } else {
      this.selecteSubEntity = false;
      this.modelPopup.subEntityId = [];
      select.value = [];
    }
  }

  /*
   * This is a description here we can select repository and subEntity value
   */
  ok(select: any, okFlag: boolean) {
    if (okFlag) {
      if (this.modelPopup.repoId.length != 0 && okFlag) select.close();
      else this.modelPopup.repoId = this.modelPopup.repoId;
    } else {
      if (this.modelPopup.subEntityId.length != 0) select.close();
      else this.modelPopup.subEntityId = this.modelPopup.subEntityId;
    }
  }

  /*
   * This is a description of the cancel
   */
  cancel() {}

  /*
   * This is a description of the toogle
   */
  schedulePopup() {
    this.scheduledPopup = !this.scheduledPopup;
    if (!this.scheduledPopup) this.clear(2);
  }

  /*
   * This is a description of too select the every value
   */
  selectEvery(every: string) {
    this.clear(2);
    this.modelPopup.cronExpression.every = every;
  }

  /*
   * This is a description of too Select the hour value
   */
  selectHour(hour: string) {
    this.modelPopup.cronExpression.hours = hour;
  }

  /*
   * This is a description of too Select the minute value
   */
  selectMinute(minute: string) {
    this.modelPopup.cronExpression.minutes = minute;
  }

  /*
   * This is a description of too Select the Week value
   */
  selectWeek(week: string) {
    this.modelPopup.cronExpression.dofWeek = week;
  }

  /*
   * This is a description of too Select the noon value
   */
  selectNoon(noon: string) {
    if (noon == Enoon.PM) {
      this.actualTime = parseInt(this.modelPopup.cronExpression.hours);
      this.actualTime = (this.actualTime + 12) % 24;
    } else {
      this.actualTime = this.modelPopup.cronExpression.hours;
    }
  }

  /*
   * This is a description of too Select the days value
   */
  selectDays(days: string) {
    //Unchecked Days value...
    if (this.daysDetails.find((x: any) => x == days)) {
      this.daysDetails.splice(
        this.daysDetails.findIndex((x: any) => x == days),
        1
      );
      this.modelPopup.cronExpression.dofWeek = this.daysDetails;
    }
    //Multi Checked Days Values Setting here...
    else {
      this.daysDetails.push(days);
      this.modelPopup.cronExpression.dofWeek = this.daysDetails
        .map((e: string) => e.replace(/\s/g, ''))
        .join(',');
    }
  }

  /*
   * This is a description of create onDemandBackup and onScheduleBackup
   * @param This is the organizationName,projectName,entity and repoId parameter
   */
  createOnDemandBackup() {
    //save method for onDemandBackupPayload...
    if (!this.isCheckedSchedule) {
      this.onDemandBackupPayload.organizationName =
        this.modelPopup.organizationName;
      this.onDemandBackupPayload.subEntitiesName = this.modelPopup.subEntityId;
      this.onDemandBackupPayload.projectName = this.modelPopup.projectName;
      this.onDemandBackupPayload.repoIds = this.modelPopup.repoId;
      
      this.sharedService

      this.sharedService
        .createOnDemandBackup(this.onDemandBackupPayload)
        .subscribe({
          next: (succ) => {
            if (succ.statusCode == 200) {
              this.onDemandBackupScheduleDetails = succ.result;
              this.getondemandBackup();
              alert(this.onDemandBackupScheduleDetails);
            }
          },
          error: (err) => {},
        });
    } else {
      ///Cron Expression
      this.modelPopup.cronExpression.hours = this.actualTime;
      if (this.modelPopup.cronExpression.every == 'D') {
        this.onScheduleBackupPayload.cronExpression =
          +this.modelPopup.cronExpression.sec +
          '  ' +
          this.modelPopup.cronExpression.minutes +
          ' ' +
          this.modelPopup.cronExpression.hours +
          ' ' +
          this.modelPopup.cronExpression.dayOfMonth +
          ' ' +
          this.modelPopup.cronExpression.month +
          ' ' +
          this.modelPopup.cronExpression.dofWeek +
          ' ' +
          this.modelPopup.cronExpression.year;
      } else if (this.modelPopup.cronExpression.every == 'M') {
        this.onScheduleBackupPayload.cronExpression =
          +this.modelPopup.cronExpression.sec +
          '  ' +
          this.modelPopup.cronExpression.minutes +
          ' ' +
          this.modelPopup.cronExpression.hours +
          ' ' +
          this.modelPopup.cronExpression.dayOfMonth +
          ' ' +
          this.modelPopup.cronExpression.month +
          ' ' +
          this.modelPopup.cronExpression.dofWeek +
          ' ' +
          this.modelPopup.cronExpression.year;
      } else if (this.modelPopup.cronExpression.every == 'W') {
        this.onScheduleBackupPayload.cronExpression =
          +this.modelPopup.cronExpression.sec +
          '  ' +
          this.modelPopup.cronExpression.minutes +
          ' ' +
          this.modelPopup.cronExpression.hours +
          ' ' +
          this.modelPopup.cronExpression.dayOfMonth +
          ' ' +
          this.modelPopup.cronExpression.month +
          ' ' +
          this.modelPopup.cronExpression.dofWeek +
          ' ' +
          this.modelPopup.cronExpression.year;
      }
      //End....
      //save method for onScheduleBackupPayload...
      this.onScheduleBackupPayload.organizationName =
        this.modelPopup.organizationName;
      this.onScheduleBackupPayload.projectName = this.modelPopup.projectName;
      this.onScheduleBackupPayload.repoIds = this.modelPopup.repoId;
      this.onScheduleBackupPayload.subEntitiesName =
        this.modelPopup.subEntityId;

      this.sharedService
        .createOnScheduleBackup(this.onScheduleBackupPayload)
        .subscribe({
          next: (succ) => {
            if (succ.statusCode == 200) {
              this.onDemandBackupScheduleDetails = succ.result;
              alert(this.onDemandBackupScheduleDetails);
              this.getondemandBackup();
            }
          },
          error: (err) => {},
        });
    }
  }

  /*
   * This is a description of clear the value
   */
  clear(val: number) {
    switch (val) {
      case 0:
        this.modelPopup.projectName = EConstant.select;
        this.modelPopup.entity = EConstant.singleQuotes;
        this.modelPopup.repoId = EConstant.singleQuotes;
        this.modelPopup.subEntityId = EConstant.singleQuotes;
        this.modelPopup.cronExpression.every = EConstant.select;
        this.modelPopup.cronExpression.sec = EConstant.number;
        this.modelPopup.cronExpression.minutes = EConstant.number;
        this.modelPopup.cronExpression.hours = EConstant.number;
        this.modelPopup.cronExpression.noon = EConstant.number;
        this.scheduledPopup = true;
        this.myCheckbox.checked = false;

        break;

      case 1:
        this.modelPopup.entity = EConstant.singleQuotes;
        this.modelPopup.repoId = EConstant.singleQuotes;
        this.modelPopup.subEntityId = EConstant.singleQuotes;
        this.modelPopup.cronExpression.every = EConstant.select;
        this.modelPopup.cronExpression.sec = EConstant.number;
        this.modelPopup.cronExpression.minutes = EConstant.number;
        this.modelPopup.cronExpression.hours = EConstant.number;
        this.modelPopup.cronExpression.noon = EConstant.number;
        this.scheduledPopup = true;
        break;

      case 2:
        this.modelPopup.cronExpression.every = EConstant.every;
        this.modelPopup.cronExpression.sec = EConstant.sec;
        this.modelPopup.cronExpression.minutes = EConstant.minutes;
        this.modelPopup.cronExpression.hours = EConstant.hours;
        this.modelPopup.cronExpression.noon = EConstant.noon;
        this.modelPopup.cronExpression.dayOfMonth = EConstant.dayOfMonth;
        this.modelPopup.cronExpression.month = EConstant.month;
        this.modelPopup.cronExpression.dofWeek = EConstant.dofWeek;
        this.modelPopup.cronExpression.year = EConstant.year;
        this.modelPopup.cronExpression.days = EConstant.days;

        break;
    }
  }

  /*
   * This is a Description of the User Details Information.
   * @param This is the User EmailId Parameter
   */
  getUserDetail() {
    this.sharedService.getUserDetailByEmailid(BACKUPDETAILS.emaiId).subscribe({
      next: (user) => {
        if (user) {
          this.backupModel.userid = user.userid;
        }
      },
    });
  }

  /*
   * This is a description of the OnDemand Backup and Details value
   * @param This is the TransactionType,userid,parameter
   */
  getondemandBackup() {
    // OnDemand Backup Details..
    this.backupModel.transactionType = BACKUPDETAILS.transactionType;
    this.sharedService.getondemandBackup(this.backupModel).subscribe({
      next: (onDemand: IBackupModel[]) => {
        if (onDemand.length != 0) {
          this.sharedService._SBackup_OnDemand.next(onDemand);
        }
      },
    });

    //// OnScheduled Backup Details..
    this.backupModel.transactionType = BACKUPDETAILS.transactionType;
    this.backupModel.isscheduled = 1;
    this.sharedService.getondemandBackup(this.backupModel).subscribe({
      next: (schedule: IBackupModel[]) => {
        if (schedule.length != 0) {
          this.sharedService._SBackup_OnSchedule.next(schedule);
        }
      },
    });
  }
}
