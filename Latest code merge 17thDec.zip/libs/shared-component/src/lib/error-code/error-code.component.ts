import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-error-code',
  templateUrl: './error-code.component.html',
  styleUrls: ['./error-code.component.scss'],
})
export class ErrorCodeComponent implements OnInit {

  constructor() {}

  ngOnInit(): void {}
}
