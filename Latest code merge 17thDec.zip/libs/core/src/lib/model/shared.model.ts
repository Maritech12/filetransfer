enum ColorTheme {
  PRIMARY = 'theme_primary',
  SECONDARY = 'theme_secondary',
}
enum ButtonType {
  PRIMARY = 'type_primary',
  SECONDARY = 'type_secondary',
}
enum PermissionsList {
  SETTING_READ = 'SR',
  SETTING_WRITE = 'SW',
  BACKUP_READ = 'BR',
  BACKUP_WRITE = 'BW',
  RESTORE_READ = 'RR',
  RESTORE_WRITE = 'RW',
  USER_MANAGEMENT_READ = 'UMR',
  USER_MANAGEMENT_WRITE = 'UMW',
  REPORT_READ = 'RRR',   
  REPORT_WRITE = 'RRW',
}
enum PageName {
  LOGIN = '',
  DASHBOARD = 'Dashboard',
  BACKUP = 'Repobackup',
  RESTORE = 'Restore',
  USER_MANAGEMEMT = 'Usermanagement',
  NOTIFICATION = 'notification',
  STORAGE = 'Storage',
  ROLE = 'Role',
  REPORT = 'Report',
  INTEGRATION = 'Integration',
  ENTITY = 'Entity',
  COMPANY = 'Company',
  BACKUP_REPORT = 'Report/backupReport',
  RESTORE_REPORT = 'Report/restoreReport',
  LOG_REPORT = 'Report/userLogReport',
  UNAUTHORIZED='UnAuthorized'
}
enum ErrorList {
  UNAUTHORIZED = 401,
  FORBIDDEN = 403,
  PAGE_NOT_FOUND = 404,
  _UNAUTHORIZED='UnAuthorized Access'
}
enum Every {
  Daily,
  Weekly,
  Monthly,
}

interface InoonList {
  noonList: Inoon[];
}
interface Inoon {
  noon: Enoon;
}
enum Enoon {
  Am = 'am',
  PM = 'pm',
}

enum EConstant {
  number = 0,
  star = '*',
  singleQuotes = '',
  doubleQuotes = '',
  select = 'Select',
  project = 0,
  entity = 1,
  every = 'Every',
  organizationName = 'clarksonscloud',
  sec = 0,
  minutes = 0,
  hours = 0,
  dayOfMonth = '?',
  month = '*',
  dofWeek = '*',
  year = '*',
  days = '',
  noon = '',
}

export {
  ColorTheme,
  ButtonType,
  PermissionsList,
  PageName,
  ErrorList,
  Every,
  Enoon,
  InoonList,
  EConstant,
};
