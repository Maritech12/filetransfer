interface IcolumnElement {
  entity: string;
  subentity: string;
  initiatedAt: string;
  completedAt: string;
  status: string;
  action: string;
}

interface ItileElement {
  id: number;
  status: string;
  BackupCount: number;
  RestoreCount: number;
}

interface IpopupElement {
  title: string;
  contentElement: string[];
}

interface ICreateOnDemandBackup {
  repoIds: string[];
  organizationName: string;
  projectName: string;
  subEntitiesName: string[];
}
interface ICreateOnScheduleBackup {
  repoIds: string[];
  organizationName: string;
  projectName: string;
  cronExpression: string;
  subEntitiesName: string[];
}

interface IBackupModel {
  transactionType: string;
  isscheduled: number;
  ReportingPeriod: number;
  projectid: number;
  userid: number;
  userDetails: string[];
}

interface IProjects {
  projectid: string;
  projectname: string;
  organizationname: string;
  criticality: string;
  isative: number;
  entitySettingsDetails: [];
  entityTransactionDetails: [];
}

interface IRepoSubentity {
  subentityid: number;
  entityid: number;
  name: string;
  order: number;
  parentid: number;
}

interface IRepository {
  organizationName: string;
  projectName: string;
}

interface IRepositoryDetails {
  id: number;
  name: string;
}

interface IMinute {
  key: string;
  value: string;
}
interface IEntity {
  id: number;
  name: string;
}
interface IEvery {
  key: string;
  value: string;
}
interface IHour {
  key: string;
  value: string;
}
interface INoon {
  key: string;
  value: string;
}
interface IDays {
  key: string;
  value: string;
}
interface IPeriod {
  key: string;
  value: string;
}

interface IWeek {
  key: string;
  value: string;
}

interface ITile {
  id: number;
  status: string;
  BackupCount: number;
  RestoreCount: number;
  class: string;
}
interface IBackup {
  Entity: string;
  Subentity: string;
  InitiatedAt: string;
  CompletedAt: string;
  Status: string;
  Action: string;
}
interface IRestore {
  Entity: string;
  Subentity: string;
  InitiatedAt: string;
  CompletedAt: string;
  Status: string;
  Action: string;
}
interface IpopoverElement {
  title: string;
  contentElement: string[];
  leftMessage: string;
  rightMessage: string[];
}

interface IOnDemandBackup {
  transactionType: string;
  isscheduled: string;
  ReportingPeriod: number;
  projectid: number;
  userid: number;
}
interface IOnScheduleBackup {
  organizationName: string;
  userid: string;
  projectid: number;
  projectName: string;
  entity: string;
  fileName: string;
  status: string;
  entityId: string;
  entityName: string;
  userName: string;
  insertedTime: string;
  subentity: string;
  completedAt: string;
  action: string;
}

interface IKeyPair {
  key: string;
  value: number;
}

export {
  IcolumnElement,
  ItileElement,
  IpopupElement,
  ICreateOnDemandBackup,
  ICreateOnScheduleBackup,
  IBackupModel,
  IProjects,
  IRepository,
  IRepoSubentity,
  IMinute,
  IEntity,
  IEvery,
  IHour,
  INoon,
  IDays,
  IPeriod,
  ITile,
  IBackup,
  IRestore,
  IpopoverElement,
  IOnDemandBackup,
  IOnScheduleBackup,
  IWeek,
  IKeyPair,
  IRepositoryDetails
};
