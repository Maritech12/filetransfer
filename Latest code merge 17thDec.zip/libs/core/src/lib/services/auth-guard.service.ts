import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  RouterStateSnapshot,
} from '@angular/router';
import { Observable, of } from 'rxjs';

import { IPermissions, Iuser, PageName, UserService } from '@ado-bcp-ui/core';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private router: Router, private userService: UserService) {}
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> {
    const currentUser: Iuser = this.userService.getCurrentUserDetails();
    if (currentUser.token != '') {
      let permissionAccess: string[] = this.userService.getPageRolePermissions(
        route.data['roles']
      );
      // check if route is restricted by role
      if (
        route.data['roles'] &&
        route.data['roles'].length > 0 &&
        permissionAccess.length < 1
      ) {
        //role not authorised so redirect to dashboard page
        this.router.navigate([PageName.UNAUTHORIZED]);
        return of(false);
      }

      // authorised so return true
      return of(true);
    }

    // not logged in so redirect to login page with the return url
    this.router.navigate([PageName.LOGIN], {
      queryParams: { returnUrl: state.url },
    });
    return of(false);
  }
}
