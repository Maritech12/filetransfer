/* eslint-disable @typescript-eslint/no-empty-function */
import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ModelPopupComponent } from '@ado-bcp-ui/shared-component';
import { MediaMatcher } from '@angular/cdk/layout';
import {
  IBackupModel,
  IPeriod,
  IProjects,
  IReadWriteAccess,
  PermissionsList,
  SharedService,
  UserService,
} from '@ado-bcp-ui/core';
import {
  BACKUPDETAILS,
  COLUMNSHEADERDETAILS,
  COLUMNSSUBHEADER,
  PERIODDETAILS,
} from '../constants/backup.constant';
// eslint-disable-next-line @nrwl/nx/enforce-module-boundaries
import { POPOVERTITLE } from 'libs/shared-component/src/lib/constants/sharedConstant';

@Component({
  selector: 'ado-bcp-ui-backup',
  templateUrl: './backup.component.html',
  styleUrls: ['./backup.component.scss'],
})
export class BackupComponent implements OnInit, OnDestroy {
  private _mobileQueryListener: () => void;
  mobileQuery: MediaQueryList;
  columnsHeaderDetails = COLUMNSHEADERDETAILS;
  columnsSubHeaderDetails = COLUMNSSUBHEADER;
  projectDetails: IProjects[] = [
    {
      projectid: '',
      projectname: '',
      organizationname: '',
      criticality: '',
      isative: 0,
      entitySettingsDetails: [],
      entityTransactionDetails: [],
    },
  ];

  backupPermission: IReadWriteAccess = {
    read: false,
    write: false,
  };

  backupModel: IBackupModel = {
    transactionType: '',
    isscheduled: 0,
    ReportingPeriod: 0,
    projectid: 0,
    userid: 0,
  };

  periodDetails: IPeriod[] = PERIODDETAILS;
  onScheduleDetails!: IBackupModel[];
  onDemandDetails!: IBackupModel[];
  backupRestoreDetails = [];
  actionViewDetails = {};
  loading: boolean = false;
  popOverTitle!: string;

  constructor(
    private dialog: MatDialog,
    changeDetectorRef: ChangeDetectorRef,
    media: MediaMatcher,
    private sharedService: SharedService,
    private userService: UserService
  ) {
    //Loading Starts
    setTimeout(() => {
      this.loading = false;
    }, 600);
    {
      this.loading = true;
    }
    //Loading Ends

    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
    //To Check the Backup Write Permissions---Start
    this.userService
      .getPagePermissions(PermissionsList.BACKUP_WRITE)
      .subscribe((data) => {
        if (data.length > 0) {
          this.backupPermission.write = data[0].write;
        }
      });

    //To Check the Backup Write Permissions---End
  }

  ngOnInit(): void {
    /*
     * This is a description of the Project Details Value.
     */
    this.getProject();

    /*
     * This is a Description of the User Details Information.
     */
    this.getUserDetail();

    /*
     * This is a Description of the OnDemand Backup and Schedule Details.
     */
    this.sharedService._SBackup_OnDemand.subscribe((val) => {
      this.onDemandDetails = val;
    });
    this.sharedService._SBackup_OnSchedule.subscribe((val) => {
      this.onScheduleDetails = val;
    });
  }

  /*
   * This is a Description of the Destory
   */
  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }

  /*
   * This is a Description of the Dialog Information
   */
  openDialog() {
    const dialogRef = this.dialog.open(ModelPopupComponent, {
      disableClose: true,
      width: '400px',
    });
  }

  /*
   * This is a Description of the Select Project Details Value
   */
  selectProject(projectid: string) {
    this.backupModel.projectid = projectid == '0' ? 0 : parseInt(projectid);
    this.getondemandBackup();
  }

  /*
   * This is a Description of the Period Details Value.
   */
  selectPeriod(period: string) {
    this.backupModel.ReportingPeriod = period == '24' ? 24 : parseInt(period);
    this.getondemandBackup();
  }

  /*
   * This is a description of the Project Details value.
   * @param This is the organizationName Parameter
   */
  getProject() {
    this.sharedService
      .getProjectDetails(BACKUPDETAILS.organizationName)
      .subscribe((resp: IProjects[]) => {
        this.projectDetails = resp;
      });
  }

  /*
   * This is a Description of the User Details Information.
   * @param This is the User EmailId Parameter
   */
  getUserDetail() {
    this.sharedService.getUserDetailByEmailid(BACKUPDETAILS.emaiId).subscribe({
      next: (user: any) => {
        if (user) {
          setTimeout(() => {
            this.backupModel.userid = user.userid;
            /*
             * This is a description of the OnDemand Backup Details Information.
             */
            this.getondemandBackup();
          }, 1000);
        }
      },
    });
  }

  /*
   * This is a Description of the OnDemandBackup and Schedule Details Value.
   */
  getondemandBackup() {
    this.backupModel.transactionType = BACKUPDETAILS.transactionType;
    this.backupModel.isscheduled = 0;
    this.onDemandDetails = [];
    this.sharedService.getondemandBackup(this.backupModel).subscribe({
      next: (onDemand: IBackupModel[]) => {
        if (onDemand.length != 0) {
          this.onDemandDetails = onDemand;
        }
      },
    });

    /*
     * This is a Bescription of the OnDemandSchedule Details Value.
     */
    this.backupModel.isscheduled = 1;
    this.onScheduleDetails = [];
    this.sharedService.getondemandBackup(this.backupModel).subscribe({
      next: (schedule: IBackupModel[]) => {
        if (schedule.length != 0) {
          this.onScheduleDetails = schedule;
        }
      },
    });
  }

  actionView(action: any) {
    // this.actionViewDetails = action;

    this.sharedService
      .getBackupRestoreDetails(action.entityTransactionId)
      .subscribe((data) => {
        this.actionViewDetails = data[0].status;
        if (this.actionViewDetails == 'Completed')
          this.popOverTitle = POPOVERTITLE.SUCCESSTITLE;
        else if (this.actionViewDetails == 'Failed')
          this.popOverTitle = POPOVERTITLE.FAILEDTITLE;
        else this.popOverTitle = POPOVERTITLE.RUNNINGTITLE;
        this.backupRestoreDetails = data;
      });
  }
}
