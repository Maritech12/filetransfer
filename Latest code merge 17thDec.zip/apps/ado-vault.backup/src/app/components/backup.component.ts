/* eslint-disable @typescript-eslint/no-empty-function */
import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ModelPopupComponent } from '@ado-bcp-ui/shared-component';
import { MediaMatcher } from '@angular/cdk/layout';
import {
  IBackupModel,
  IPeriod,
  IProjects,
  IReadWriteAccess,
  PermissionsList,
  SharedService,
  UserService,
} from '@ado-bcp-ui/core';
import {
  BACKUPDETAILS,
  COLUMNSHEADERDETAILS,
  COLUMNSSUBHEADER,
  PERIODDETAILS,
} from '../constants/backup.constant';

@Component({
  selector: 'ado-bcp-ui-backup',
  templateUrl: './backup.component.html',
  styleUrls: ['./backup.component.scss'],
})
export class BackupComponent implements OnInit, OnDestroy {
  private _mobileQueryListener: () => void;
  mobileQuery: MediaQueryList;
  columnsHeaderDetails = COLUMNSHEADERDETAILS;
  columnsSubHeaderDetails = COLUMNSSUBHEADER;
  projectDetails: IProjects[] = [
    {
      projectid: '',
      projectname: '',
      organizationname: '',
      criticality: '',
      isative: 0,
      entitySettingsDetails: [],
      entityTransactionDetails: [],
    },
  ];

  backupPermission: IReadWriteAccess = {
    read: false,
    write: false,
  };

  backupModel: IBackupModel = {
    transactionType: '',
    isscheduled: 0,
    ReportingPeriod: 0,
    projectid: 0,
    userid: 0,
    userDetails: [],
  };

  periodDetails: IPeriod[] = PERIODDETAILS;
  onScheduleDetails: IBackupModel[] = [];
  onDemandDetails: IBackupModel[] = [];
  backupRestoreDetails = [];
  actionViewDetails = {};
  loading: boolean = false;
  popOverTitle!: string;

  constructor(
    private dialog: MatDialog,
    changeDetectorRef: ChangeDetectorRef,
    media: MediaMatcher,
    private sharedService: SharedService,
    private userService: UserService
  ) {
    //Loading Starts
    // setTimeout(() => {
    //   this.loading = false;
    // }, 600);
    // {
    //   this.loading = true;
    // }
    //Loading Ends

    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
    //To Check the Backup Write Permissions---Start
    this.userService
      .getPagePermissions(PermissionsList.BACKUP_WRITE)
      .subscribe({
        next: (data) => {
          if (data.length > 0) {
            this.backupPermission.write = data[0].write;
          }
        },
      });

    //To Check the Backup Write Permissions---End
  }

  ngOnInit(): void {
    /*
     * To get the Project Details Information.
     */
    this.getProject();

    /*
     * To get the User Details Information.
     */
    this.getUserDetail();

    /*
     * To get the OnDemand Backup and Schedule Details Information.
     */
    this.sharedService._SBackup_OnDemand.subscribe({
      next: (onDemand) => {
        this.onDemandDetails = onDemand;
      },
    });
    this.sharedService._SBackup_OnSchedule.subscribe({
      next: (schedule) => {
        this.onScheduleDetails = schedule;
      },
    });
  }

  /*
   * This is a Description of the Destory
   */
  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }

  /*
   * This is a Description of the Dialog Information
   */
  openDialog() {
    const dialogRef = this.dialog.open(ModelPopupComponent, {
      disableClose: true,
      width: '400px',
    });
  }

  closeDialog(){
    this.dialog.closeAll()
  }

  /*
   * Select the Project Details Value
   */
  selectProject(projectid: string) {
    this.backupModel.projectid = projectid == '0' ? 0 : parseInt(projectid);
    this.getondemandBackup();
  }

  /*
   * Selectcthe Period Details value.
   */
  selectPeriod(period: string) {
    this.backupModel.ReportingPeriod = period == '24' ? 24 : parseInt(period);
    this.getondemandBackup();
  }

  /*
   * Get the Project Details Information.
   * @param This is the organizationName Parameter
   */
  getProject() {
    this.loading=true;
    this.sharedService
      .getProjectDetails(BACKUPDETAILS.organizationName)
      .subscribe({
        next: (projectResponse: IProjects[]) => {
          if (projectResponse.toString() != '') {
            this.projectDetails = projectResponse;
          }
        },
      });
  }

  /*
   * Get the User Details Information.
   * @param This is the User EmailId Parameter
   */
  getUserDetail() {
    this.sharedService
      .getUserDetailByEmailid(
        JSON.parse(window.localStorage['userDetails']).email
      )
      .subscribe({
        next: (userResponse: any) => {
          if (userResponse != null) {
            this.backupModel.userDetails = userResponse;
            this.backupModel.userid = userResponse.userid;
            /*
             * Get the OnDemand Backup Details Information.
             */
            this.getondemandBackup();
          }
        },
      });
  }

  /*
   * Get OnDemandBackup and Schedule Details Value.
   */
  getondemandBackup() {
    this.backupModel.transactionType = BACKUPDETAILS.transactionType;
    this.backupModel.isscheduled = 0;
    this.onDemandDetails = [];
    this.loading = true;
    this.sharedService.getondemandBackup(this.backupModel).subscribe({
      next: (onDemand: IBackupModel[]) => {
        if (onDemand.length != 0) {
          this.onDemandDetails = onDemand;
          this.loading = false;
        }
      },
    });

    /*
     * Get the OnDemandSchedule Details Value.
     */
    this.backupModel.isscheduled = 1;
    this.onScheduleDetails = [];
    this.sharedService.getondemandBackup(this.backupModel).subscribe({
      next: (schedule: IBackupModel[]) => {
        if (schedule.length != 0) {
          this.onScheduleDetails = schedule;
        }
      },
    });
  }

  /*
   * Get the Action Details Value.
   */
  actionView(action: any) {
    this.sharedService
      .getBackupRestoreDetails(action.entityTransactionId)
      .subscribe({
        next: (actionResponse) => {
          if (actionResponse != '') {
            this.backupRestoreDetails = actionResponse;
          }
        },
      });
  }
}
