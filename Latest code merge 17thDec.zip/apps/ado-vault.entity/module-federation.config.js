module.exports = {
  name: 'ado-vault.entity',
  exposes: {
    './Module': 'apps/ado-vault.entity/src/app/remote-entry/entry.module.ts',
  },
};
