export class NotificationModel {}
