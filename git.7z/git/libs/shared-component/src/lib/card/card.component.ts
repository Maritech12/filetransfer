import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss'],
})
export class CardComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}