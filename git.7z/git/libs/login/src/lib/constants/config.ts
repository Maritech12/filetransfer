export class Config {
  public static CLIENTID = '1ed13e1b-5411-401c-8802-3adfd7974f1a';
  public static REDIRECTURI = 'http://localhost:4200';
}
