import {MediaMatcher} from '@angular/cdk/layout';
import { Component, ChangeDetectorRef, OnInit } from '@angular/core';


@Component({
  selector: 'ado-bcp-ui-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
})
export class SidebarComponent implements OnInit  {

  color = false;
  panelOpenState = false; 

  displayedColumns = [
    'entity',
    'subentity',
    'initiatedAt',
    'completedAt',
    'status',
    'action',
  ];
  dataSource = ELEMENT_DATA;


 
    mobileQuery: MediaQueryList;

    private _mobileQueryListener: () => void;
  
    constructor(changeDetectorRef: ChangeDetectorRef, media: MediaMatcher) {
      this.mobileQuery = media.matchMedia('(max-width: 600px)');
      this._mobileQueryListener = () => changeDetectorRef.detectChanges();
      this.mobileQuery.addListener(this._mobileQueryListener);
    }
  
    ngOnDestroy(): void {
      this.mobileQuery.removeListener(this._mobileQueryListener);
    }
  
    
  
  
  // eslint-disable-next-line @typescript-eslint/no-empty-function
  ngOnInit(): void {
  }


}export interface PeriodicElement {
  entity: string;
  subentity: string;
  initiatedAt: string;
  completedAt: string;
  status: string;
  action: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {entity: 'WorK Item <br> <small>UI-Design</small>', subentity: 'Epics', initiatedAt: '22-06-2022 <br> <small class="time">19:22</small>', completedAt: '22-06-2022 <br> <small class="time">19:32</small>', status: '<span class="text-warning">Running</span>', action: 'Eye'},
  {entity: 'Repo <br> <small>ADO-BCP-API</small>', subentity: 'Branch', initiatedAt: '22-06-2022 <br> <small class="time">15:05</small>', completedAt: '22-06-2022 <br> <small class="time">15:20</small>', status: '<span class="text-success">Successful</span>', action: 'Eye'},
  {entity: 'Pipeline <br> <small>Database Pipeline</small>', subentity: 'Task Group', initiatedAt: '22-06-2022 <br> <small class="time">14:00</small>', completedAt: '22-06-2022 <br> <small class="time">14:10</small>', status: '<span class="text-danger">Failed</span>', action: 'Eye'},
];


