export class IntegrationModel {}
