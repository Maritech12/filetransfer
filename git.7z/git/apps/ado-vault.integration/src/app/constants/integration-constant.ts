export class ScreenId {
  public static WELCOME_SCREEN = 'Welcome to Integration';
}
