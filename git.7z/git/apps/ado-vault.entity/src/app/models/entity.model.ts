export class EntityModel {}
