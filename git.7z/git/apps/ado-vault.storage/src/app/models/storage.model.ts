export class StorageModel {}
