import { Route } from '@angular/router';
import { StorageComponent } from '../components/storage.component';

export const remoteRoutes: Route[] = [
  { path: '', component: StorageComponent },
];
