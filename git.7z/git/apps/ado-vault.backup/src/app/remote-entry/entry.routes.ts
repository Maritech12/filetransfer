import { Route } from '@angular/router';
import { BackupComponent } from '../components/backup.component';

export const remoteRoutes: Route[] = [{ path: '', component: BackupComponent }];
