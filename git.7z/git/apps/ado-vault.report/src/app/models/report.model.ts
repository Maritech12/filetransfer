export class ReportModel {}
