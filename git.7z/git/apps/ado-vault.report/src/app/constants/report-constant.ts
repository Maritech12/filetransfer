export class ScreenId {
  public static WELCOME_SCREEN = 'Welcome to Report';
  public static WELCOME_BACKUP_REPORT = 'Welcome to Backup Report';
  public static WELCOME_RESTORE_REPORT = 'Welcome to Restore Report';
  public static WELCOME_USER_REPORT = 'Welcome to User Log Report';
}
