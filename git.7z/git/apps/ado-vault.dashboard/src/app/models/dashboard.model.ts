export class DashboardModel {}
