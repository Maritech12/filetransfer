export class NotificationModel {}
