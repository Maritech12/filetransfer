export class CompanyModel {}
