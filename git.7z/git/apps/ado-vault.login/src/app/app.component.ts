import { Component } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'ado-vault.login';
}
