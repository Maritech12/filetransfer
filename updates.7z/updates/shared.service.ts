/* eslint-disable @nrwl/nx/enforce-module-boundaries */

import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import {
  ApiService,
  ImenuElement,
  InotificationElement,
  IpopupElement,
  ItileElement,
  environment,
  IcolumnElement,
} from '@ado-bcp-ui/core';

@Injectable({
  providedIn: 'root',
})
export class SharedService {
  getValueDetails() {
    throw new Error('Method not implemented.');
  }
  constructor(private apiService: ApiService) {}

  getNotificationDetails(): Observable<InotificationElement> {
    return this.apiService.get(`${environment.api_url}/notifications`).pipe(
      map((data) => {
        return data;
      })
    );
  }
  getBackupPopupDetails(): Observable<IpopupElement> {
    return this.apiService.get(`${environment.api_url}/popupTitle`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getMenuDetails(): Observable<ImenuElement> {
    return this.apiService.get(`${environment.api_url}/menuElement`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getDashboardTileDetails(): Observable<ItileElement> {
    return this.apiService.get(`${environment.api_url}/titleData`).pipe(
      map((data) => {
        return data;
      })
    );
  }


  getProjectDetails(): Observable<IcolumnElement> {
    return this.apiService.get(`${environment.api_url}/ddlProjectData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getPeriodsDetails(): Observable<IcolumnElement> {
    return this.apiService.get(`${environment.api_url}/ddlPeriodData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getEntityDetails(): Observable<IcolumnElement> {
    return this.apiService.get(`${environment.api_url}/ddlEntityData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getRepositoryDetails(): Observable<IcolumnElement> {
    return this.apiService.get(`${environment.api_url}/ddlRepositoryData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getRepoSubentityDetails(): Observable<IcolumnElement> {
    return this.apiService.get(`${environment.api_url}/ddlRepoSubentityData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getWorkitemSubentityDetails(): Observable<IcolumnElement> {
    return this.apiService.get(`${environment.api_url}/ddlWorkitemSubentityData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getEveryDetails(): Observable<IcolumnElement> {
    return this.apiService.get(`${environment.api_url}/ddlEveryData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getHourDetails(): Observable<IcolumnElement> {
    return this.apiService.get(`${environment.api_url}/ddlHourData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getMinuteDetails(): Observable<IcolumnElement> {
    return this.apiService.get(`${environment.api_url}/ddlMinuteData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getNoonDetails(): Observable<IcolumnElement> {
    return this.apiService.get(`${environment.api_url}/ddlNoonData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getLabelDetails(): Observable<IcolumnElement> {
    return this.apiService.get(`${environment.api_url}/labelData`).pipe(
      map((data) => {
        return data;
      })
    );
  }


  getButtonDetails(): Observable<IcolumnElement> {
    return this.apiService.get(`${environment.api_url}/buttonData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  getBackupDetails(): Observable<IcolumnElement> {
    return this.apiService.get(`${environment.api_url}/getBackupDetails`).pipe(
      map((data) => {
        return data;
      })
    );
  }

}
