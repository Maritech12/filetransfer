import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class BackupService {
  getBackupDetails() {
    throw new Error('Method not implemented.');
  }
  getRestoreDetails() {
    throw new Error('Method not implemented.');
  }
  getPeriodsDetails() {
    throw new Error('Method not implemented.');
  }
  getProjectDetails() {
    throw new Error('Method not implemented.');
  }
}
