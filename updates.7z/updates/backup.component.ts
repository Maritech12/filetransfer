import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { ScreenId } from '../constants/backup.constant';
import {MatDialog} from '@angular/material/dialog';
import { ModelPopupComponent } from '@ado-bcp-ui/shared-component';
import { BackupService } from '../service/backup.service';
import { MediaMatcher } from '@angular/cdk/layout';
import { Title } from '@angular/platform-browser';
import { SharedService } from '@ado-bcp-ui/core';


@Component({
  selector: 'ado-bcp-ui-backup',
  templateUrl: './backup.component.html',
  styleUrls: ['./backup.component.scss'],
})
export class BackupComponent implements OnInit, OnDestroy {
  mobileQuery: MediaQueryList;
  show: any;  
  ddlProjectData: any;
  ddlPeriodData: any;
  ddlEntityData: any;
  

  private _mobileQueryListener: () => void;

  constructor(public dialog: MatDialog,private sharedService :SharedService,private backupService:BackupService,changeDetectorRef: ChangeDetectorRef,private title: Title,
    media: MediaMatcher) {
    this.show = ScreenId.WELCOME_SCREEN;
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
  }
  ngOnInit(): void {    
    
    this.sharedService.getProjectDetails().subscribe((data) => {
      this.ddlProjectData = data;
    });
    
    this.sharedService.getPeriodsDetails().subscribe((data) => {
      this.ddlPeriodData = data;
    });
    
    this.sharedService.getEntityDetails().subscribe((data) => {
      this.ddlEntityData = data;
    });
    /*this.backupService.getProjectDetails().subscribe((data) => {
      this.ddlProjectData = data;
    });
    this.backupService.getPeriodsDetails().subscribe((data) => {
      this.ddlPeriodData = data;
    });*/
  }

  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }
  
 
  openDialog() {
    const dialogRef = this.dialog.open(ModelPopupComponent);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }
  

}
