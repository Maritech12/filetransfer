import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss'],
})
export class LoaderComponent implements OnInit {
  constructor() {}
  loading = false;

  ngOnInit(): void {

    //Loading Starts
    setTimeout(() => { this.loading = false; }, 500);
    {
     this.loading = true;
    }
   //Loading Ends
   
  }
}
