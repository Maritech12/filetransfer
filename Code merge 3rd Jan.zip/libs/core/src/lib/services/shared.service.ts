import { Injectable } from '@angular/core';
import { map, Observable, ReplaySubject, Subject } from 'rxjs';
import {
  ApiService,
  InotificationElement,
  IpopupElement,
  ItileElement,
  environment,
  ICreateOnScheduleBackup,
  ICreateOnDemandBackup,
  IRepository,
  ISubEntity,
  IEntity,
  IPeriod,
  IPermissions,
  IUser,
  IOnScheduleBackup,
  IBackupModel,
  Params,
} from '@ado-bcp-ui/core';

import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class SharedService {
  public _SProject_Data = new Subject<any>();
  public _STile_Data = new Subject<any>();
  public _SBackup_Data = new Subject<any>();
  public dashBoardOnDemandSubject = new Subject<any>();
  public dashboardOnScheduleSubject = new Subject<any>();
  public _SRestore_Data = new Subject<any>();
  public _SEntity_Data = new Subject<any>();
  public _SMessage = new ReplaySubject<any>();

  constructor(private apiService: ApiService, private http: HttpClient) {}

  /*
   * To get the  Dashboard,BackuP and Restore Table Information.
   * @param This is the TransactionType,IsScheduled,ReportingPeriod,ProjectId,UserId Parameter
   */
  getDashBoardsTableDetails(ondemandBackup: IBackupModel): Observable<any> {
    const params = new HttpParams()
      .set('TransactionType', ondemandBackup.transactionType)
      .set('isscheduled', ondemandBackup.isscheduled)
      .set('ReportingPeriod', ondemandBackup.ReportingPeriod)
      .set('projectid', ondemandBackup.projectid)
      .set('userid', ondemandBackup.userid);
    return this.apiService
      .get(`${environment.base_api}/api/Report/GetDashboarddetails`, params)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * To get the Action View Information.
   * @param This is the transactionId parameter
   */
  getLogDetails(transactionId: string): Observable<any> {
    const params = new HttpParams().set('entityTransactionId', transactionId);
    return this.apiService
      .get(`${environment.base_api}/api/Report/GetTaskDetails`, params)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * Create the OnDemand Backup.
   * @param This is the OrganizationName,ProjectName,Entity and RepoIds Parameter
   */
  createOnDemandBackup(paramsOnDemand: ICreateOnDemandBackup): Observable<any> {
    return this.apiService
      .post(
        `${environment.base_api}/api/ondemandbackup/repository`,
        paramsOnDemand
      )
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * Create the OnSchedule Backup.
   * @param This is the OrganizationName,ProjectName,Entity,CronExpression and RepoId parameter
   */
  createOnScheduleBackup(
    paramsSchedule: ICreateOnScheduleBackup
  ): Observable<any> {
    return this.apiService
      .post(
        `${environment.base_api}/api/schedulebackup/repository`,
        paramsSchedule
      )
      .pipe(
        map((scheduleResponse) => {
          return scheduleResponse;
        })
      );
  }

  /*
   * To get the OnSchedule Backup Information.
   * @param This is the UserId,ProjectId parameter
   */
  getonScheduleBackup(onScheduleBackup: IOnScheduleBackup): Observable<any> {
    const params = new HttpParams()
      .set('userid', onScheduleBackup.userid)
      .set('projectid', onScheduleBackup.projectid);
    return this.apiService
      .get(
        `${environment.base_api}${environment._web}/GetScheduleBackupTransaction`,
        params
      )
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * To get User Details Information.
   * @param This is EmailId Parameter
   */
  getUserDetailByEmailId(emailid: string): Observable<any> {
    const params = new HttpParams().set(Params.EmailId, emailid);
    return this.apiService
      .get(
        `${environment.base_api}/api/UserManagement/Getusercompanydetails`,
        params
      )
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * To get the Project Details Information.
   * @param This is OrganisationName parameter
   */
  getProjectDetails(projectDetails: string): Observable<any> {
    const params = new HttpParams().set('organisation', projectDetails);
    return this.apiService
      .get(`${environment.base_api}${environment._web}/GetProjects`, params)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * To get the Entity Details Information.
   */
  getEntityDetails(): Observable<IEntity[]> {
    return this.apiService
      .get(`${environment.base_api}${environment._web}/GetEntity`)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * To get the Repository Details Information.
   * @param This is OrganisationName,ProjectName Parameter
   */
  getRepositoryDetails(repositoryDetails: IRepository): Observable<any> {
    const params = new HttpParams()
      .set('organization', repositoryDetails.organization)
      .set('project', repositoryDetails.project);
    return this.apiService
      .get(`${environment.base_api}/api/repositories`, params)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }
  /*
   * To get SubEntity the Details Information.
   */
  getSubEntityDetails(): Observable<ISubEntity[]> {
    return this.apiService
      .get(`${environment.base_api}${environment._web}/GetSubEntity`)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }
  /*
   * Backup End....
   */

  /* Restore....
   * Create the OnDemand Restore.
   * @param This is the OrganizationName,ProjectName,Repositories,Blobs and SubEntities parameter
   */
  createOnDemandRestore(paramsOnDemand: any): Observable<any> {
    return this.apiService
      .post(
        `${environment.base_api}/api/ondemandrestore/repository`,
        paramsOnDemand
      )
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * Create the OnSchedule Restore.
   */
  createOnScheduleRestore(paramsOnSchedule: string): Observable<any> {
    return this.apiService
      .post(
        `${environment.base_api}/api/schedulerestore/repository`,
        paramsOnSchedule
      )
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * To get the Blob Details Information.
   */
  getRestoreBlobsDetails(onDemandRestoreBlob: any): Observable<any> {
    return this.apiService
      .post(
        `${environment.base_api}/api/ondemandrestore/subentityblobs`,
        onDemandRestoreBlob
      )
      .pipe(
        map((restoreBlobResponse) => {
          return restoreBlobResponse;
        })
      );
  }
  /*
   * Restore End....
   */

  /*
   * To get the Role Permissions Details Information.
   */
  getRolePermissions(UserDetails: IUser): Observable<IPermissions[]> {
    try {
      const params = new HttpParams().set(Params.EmailId, UserDetails.email);
      return this.apiService
        .get(
          `${environment.base_api}${environment._web}/GetPermissionByEmailid`,
          params
        )
        .pipe(
          map((data: IPermissions[]) => {
            return data;
          })
        );
    } catch (error: any) {
      return error;
    }
  }

  /* Dashboard...
   * To get the Notification Details Information.
   */
  getNotificationDetails(): Observable<InotificationElement> {
    return this.apiService.get(`${environment.api_url}/notifications`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  /*
   * To get the BackupPopup Details Information.
   */
  getBackupPopupDetails(): Observable<IpopupElement> {
    return this.apiService.get(`${environment.api_url}/popupTitle`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  /*
   * To get the DashboardTile Details Information.
   */
  getDashboardTileDetails(): Observable<ItileElement> {
    return this.apiService.get(`${environment.api_url}/titleData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  /*
   * To get the Periods Details Information.
   */
  getPeriodsDetails(): Observable<IPeriod[]> {
    return this.apiService.get(`${environment.api_url}/ddlPeriodData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  /*
   * To get the Backup Details Information.
   */
  getBackupDetails() {
    return this.apiService.get(`${environment.api_url}/getBackupDetails`).pipe(
      map((data) => {
        return data;
      })
    );
  }
}
