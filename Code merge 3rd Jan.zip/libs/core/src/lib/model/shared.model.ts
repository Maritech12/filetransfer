enum ColorTheme {
  PRIMARY = 'theme_primary',
  SECONDARY = 'theme_secondary',
}
enum ButtonType {
  PRIMARY = 'type_primary',
  SECONDARY = 'type_secondary',
}
enum PermissionsList {
  SETTING_READ = 'SR',
  SETTING_WRITE = 'SW',
  BACKUP_READ = 'BR',
  BACKUP_WRITE = 'BW',
  RESTORE_READ = 'RR',
  RESTORE_WRITE = 'RW',
  USER_MANAGEMENT_READ = 'UMR',
  USER_MANAGEMENT_WRITE = 'UMW',
  REPORT_READ = 'RRR',   
  REPORT_WRITE = 'RRW',
}
enum PageName {
  LOGIN = '',
  DASHBOARD = 'Dashboard',
  BACKUP = 'Repobackup',
  RESTORE = 'Restore',
  USER_MANAGEMEMT = 'Usermanagement',
  NOTIFICATION = 'notification',
  STORAGE = 'Storage',
  ROLE = 'Role',
  REPORT = 'Report',
  INTEGRATION = 'Integration',
  ENTITY = 'Entity',
  COMPANY = 'Company',
  BACKUP_REPORT = 'Report/backupReport',
  RESTORE_REPORT = 'Report/restoreReport',
  LOG_REPORT = 'Report/userLogReport',
  UNAUTHORIZED='UnAuthorized'
}
enum ErrorList {
  UNAUTHORIZED = 401,
  FORBIDDEN = 403,
  PAGE_NOT_FOUND = 404,
  _UNAUTHORIZED='UnAuthorized Access'
}
enum EVERY {
  DAILY,
  WEEKLY,
  MONTHLY,
}

interface INOONLIST {
  NOONLIST: INOON[];
}
interface INOON {
  NOONDETAILS: NOON;
}
enum NOON {
  AM = 'am',
  PM = 'pm',
}
enum Params{
  EmailId='emailid'
}

enum CONSTANT {
  NUMBER = 0,
  STAR = '*',
  SINGLEQUOTES = '',
  DOUBLEQUOTES = '',
  SELECT = 'Select',
  PROJECT = 0,
  ENTITY = 1,
  EVERY = 'Every',
  ORGANIZATIONNAME = 'clarksonscloud',
  SEC = 0,
  MINUTES = 0,
  HOURS = 0,
  DAYOFMONTH = '?',
  MONTH = '*',
  DOFWEEK = '*',
  YEAR = '*',
  DAYS = '',
  NOON = '',
}

export {
  ColorTheme,
  ButtonType,
  PermissionsList,
  PageName,
  ErrorList,
  EVERY,
  NOON,
  INOONLIST,
  CONSTANT,
  Params
};
