import { Component, VERSION, ViewChild } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-root',
  template: ` <ado-bcp-ui-table from="{{ show }}"></ado-bcp-ui-table>`,
})
export class AppComponent {
  show: any;
  ngVersion: string = VERSION.full;
}
