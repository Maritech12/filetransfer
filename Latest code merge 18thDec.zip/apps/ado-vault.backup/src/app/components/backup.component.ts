import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ModelPopupComponent } from '@ado-bcp-ui/shared-component';
import { MediaMatcher } from '@angular/cdk/layout';
import {
  IBackupModel,
  IPeriod,
  IProjects,
  IReadWriteAccess,
  PermissionsList,
  SharedService,
  UserService,
} from '@ado-bcp-ui/core';
import {
  BACKUPDETAILS,
  COLUMNSHEADERDETAILS,
  COLUMNSSUBHEADER,
  PERIODDETAILS,
} from '../constants/backup.constant';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';

@Component({
  selector: 'ado-bcp-ui-backup',
  templateUrl: './backup.component.html',
  styleUrls: ['./backup.component.scss'],
})
export class BackupComponent implements OnInit, OnDestroy {
  private _mobileQueryListener: () => void;
  mobileQuery: MediaQueryList;
  columnsHeaderDetails = COLUMNSHEADERDETAILS;
  columnsSubHeaderDetails = COLUMNSSUBHEADER;
  projectDetails: IProjects[] = [
    {
      projectid: '',
      projectname: '',
      organizationname: '',
      criticality: '',
      isative: 0,
      entitySettingsDetails: [],
      entityTransactionDetails: [],
    },
  ];

  backupPermission: IReadWriteAccess = {
    read: false,
    write: false,
  };

  backupModel: IBackupModel = {
    transactionType: '',
    isscheduled: 0,
    ReportingPeriod: 0,
    projectid: 0,
    userid: 0,
    userDetails: [],
  };

  periodDetails: IPeriod[] = PERIODDETAILS;
  onScheduleDetails: IBackupModel[] = [];
  onDemandDetails: IBackupModel[] = [];
  popOverDetails = [];
  actionViewDetails = {};
  loading: boolean;
  popOverTitle!: string;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(
    private dialog: MatDialog,
    changeDetectorRef: ChangeDetectorRef,
    media: MediaMatcher,
    private sharedService: SharedService,
    private userService: UserService,
    private _snackBar: MatSnackBar
  ) {
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
    this.loading = false;
    //To Check the Backup Write Permissions---Start
    this.userService
      .getPagePermissions(PermissionsList.BACKUP_WRITE)
      .subscribe({
        next: (permissionResponse) => {
          if (permissionResponse.length > 0) {
            this.backupPermission.write = permissionResponse[0].write;
          }
        },
      });

    //To Check the Backup Write Permissions---End
  }

  ngOnInit(): void {
    /*
     * To get the User Details and Project Details Information.
     */
    this.loading = true;
    this.getUserDetail().then((userDetails) => {
      /*
       * To get the Project Details Information.
       */
      this.getProject(userDetails);
    });

    /*
     * To get the OnDemand Backup and Schedule Details Information.
     */
    this.sharedService.backupOnDemandSubject.subscribe({
      next: (onDemandResponse) => {
        this.onDemandDetails = onDemandResponse;
      },
    });
    this.sharedService.backupOnScheduleSubject.subscribe({
      next: (scheduleResponse) => {
        this.onScheduleDetails = scheduleResponse;
      },
    });
  }

  /*
   * This is a Description of the Destory
   */
  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }

  /*
   * To open the Model Popup Window.
   */
  openDialog() {
    this.dialog.open(ModelPopupComponent, {
      disableClose: true,
      width: '400px',
    });
  }

  closeDialog() {
    this.dialog.closeAll();
  }

  /*
   * Select the Project Details Value.
   */
  selectProject(projectid: string) {
    this.backupModel.projectid = projectid == '0' ? 0 : parseInt(projectid);
    this.getOnDemandBackup();
  }

  /*
   * Select the Period Details Value.
   */
  selectPeriod(period: string) {
    this.backupModel.ReportingPeriod = period == '1' ? 1 : parseInt(period);
    this.getOnDemandBackup();
  }

  /*
   * To get the Project Details Information.
   * @param This is the organizationName Parameter
   */
  getProject(userDetails: any) {
    this.sharedService
      .getProjectDetails(userDetails['companyModels'][0].companyname)
      .subscribe({
        next: (projectResponse: IProjects[]) => {
          if (projectResponse.length > 0) {
            this.projectDetails = projectResponse;
            this.loading = false;
          }
        },
        error: (errorResponse) => {
          this.openSnackBar(errorResponse);
          this.loading = false;
        },
      });
  }

  /*
   * To get the User Details Information.
   * @param This is the User EmailId Parameter
   */
  getUserDetail() {
    return new Promise<void>((resolve) => {
      const UserDetails = this.userService.getCurrentUserDetails();
      this.sharedService.getUserDetailByEmailId(UserDetails.email).subscribe({
        next: (userResponse) => {
          if (userResponse != null) {
            this.backupModel.userDetails = userResponse.userModel;
            this.backupModel.userid = userResponse.userModel.userid;
            /*
             * Get the OnDemand Backup Details Information.
             */
            this.getOnDemandBackup();
            resolve(userResponse);
          }
        },
        error: (errorResponse) => {
          this.openSnackBar(errorResponse);
          this.loading = false;
        },
      });
    });
  }

  /*
   * To get OnDemandBackup and Schedule Details Value.
   */
  getOnDemandBackup() {
    this.backupModel.transactionType = BACKUPDETAILS.transactionType;
    this.backupModel.isscheduled = 0;
    this.onDemandDetails = [];
    this.loading = true;
    this.sharedService.getOnDemandBackup(this.backupModel).subscribe({
      next: (onDemandResponse: IBackupModel[]) => {
        if (onDemandResponse.length != 0) {
          this.onDemandDetails = onDemandResponse;
        }
        this.loading = false;
      },
      error: (errorResponse) => {
        this.openSnackBar(errorResponse);
        this.loading = false;
      },
    });

    /*
     * To get the OnDemandSchedule Details Value.
     */
    this.backupModel.isscheduled = 1;
    this.onScheduleDetails = [];
    this.loading = true;
    this.sharedService.getOnDemandBackup(this.backupModel).subscribe({
      next: (onScheduleResponse: IBackupModel[]) => {
        if (onScheduleResponse.length != 0) {
          this.onScheduleDetails = onScheduleResponse;
        }
        this.loading = false;
      },
      error: (errorResponse) => {
        this.openSnackBar(errorResponse);
        this.loading = false;
      },
    });
  }

  /*
   * To get the Action Details Value.
   */
  actionView(action: any) {
    this.sharedService
      .getBackupRestoreDetails(action.entityTransactionId)
      .subscribe({
        next: (actionResponse) => {
          if (actionResponse != '') {
            this.popOverDetails = actionResponse;
          }
        },
      });
  }

  /*
   * To Show the Message Content.
   */
  openSnackBar(message: string) {
    this._snackBar.open(message, '', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 3000,
      panelClass: ['snackbar-success'],
    });
  }
}
