/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @angular-eslint/component-selector */
import { PermissionsList, SharedService, UserService } from '@ado-bcp-ui/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { DashboardService } from '../../service/dashboard.service';

@Component({
  selector: 'maritech-storage-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit, OnDestroy {
  mobileQuery: MediaQueryList;
  displayedColumnsData = DISPLAYCOLOUMNS;
  backupDetails: any;
  restoreDetails: any;
  ddlProjectData: any;
  ddlPeriodData: any;
  key: any = 'id';
  value: any = 'name';
  permissionList = PermissionsList;
  private _mobileQueryListener: () => void;

  constructor(
    changeDetectorRef: ChangeDetectorRef,
    private title: Title,
    media: MediaMatcher,
    private dashBoardService: DashboardService,
    private sharedService: SharedService,
    private userService: UserService
  ) {
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
  }

  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }

  // eslint-disable-next-line @typescript-eslint/no-empty-function
  ngOnInit(): void {
    this.title.setTitle('Dashboard');
    /* For testing purposes we have created the service


    // this.dashBoardService.getBackupDetails().subscribe((data) => {
    //   this.backupDetails = data;
    // });
    // this.dashBoardService.getRestoreDetails().subscribe((data) => {
    //   this.restoreDetails = data;
    // });
    // this.dashBoardService.getProjectDetails().subscribe((data) => {
    //   this.ddlProjectData = data;
    // });
    // this.dashBoardService.getPeriodsDetails().subscribe((data) => {
    //   this.ddlPeriodData = data;
    // });

    // this.sharedService._SBackup_Data.subscribe((val) => {
    //   this.backupDetails = val;
    //   console.log('backupDetails', this.backupDetails);
    // });

    // this.sharedService._SRestore_Data.subscribe((val) => {
    //   this.restoreDetails = val;
    //   console.log('restoreDetails', this.restoreDetails);
    // });
    */
  }
  // To get the read and write permissions for page
  readWritePermissions(pagename: string[]) {
    const permission: string[] =
      this.userService.getPageRolePermissions(pagename);
    return permission.length > 0 ? true : false;
  }
}

const DISPLAYCOLOUMNS = [
  'Entity',
  'Subentity',
  'Initiated At',
  'Completed At',
  'Status',
  'Action',
];
