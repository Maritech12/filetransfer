import { Route } from '@angular/router';
import { IntegrationComponent } from '../components/integration.component';

export const remoteRoutes: Route[] = [
  { path: '', component: IntegrationComponent },
];
