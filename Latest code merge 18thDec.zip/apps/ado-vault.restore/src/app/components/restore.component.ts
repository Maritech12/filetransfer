import {
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  VERSION,
} from '@angular/core';
import { ScreenId } from '../constants/restore-constant';
import { MatDialog } from '@angular/material/dialog';
import { ModelPopupComponent } from '@ado-bcp-ui/shared-component';
import { RestoreService } from '../service/restore.service';
import { MediaMatcher } from '@angular/cdk/layout';
import { Title } from '@angular/platform-browser';
import {
  IReadWriteAccess,
  PermissionsList,
  SharedService,
  UserService,
} from '@ado-bcp-ui/core';

@Component({
  selector: 'ado-bcp-ui-restore',
  templateUrl: './restore.component.html',
  styleUrls: ['./restore.component.scss'],
})
export class RestoreComponent implements OnInit, OnDestroy {
  mobileQuery: MediaQueryList;
  show: any;
  isOpenoverlay = false;
  displayedColumnsData = DISPLAYCOLOUMNS;
  restoreDetails: any=[];
  ddlProjectData: any;
  ddlPeriodData: any;
  ddlEntityData: any;

  ngVersion: string = VERSION.full;
  xsmall!: number;
  xsmallPopover!: number;
  medium!: number;
  isOpen = false;

  userDetails: any;
  restorePermission: IReadWriteAccess = {
    read: false,
    write: false,
  };
  private _mobileQueryListener: () => void;

  constructor(
    public dialog: MatDialog,
    private restoreService: RestoreService,
    changeDetectorRef: ChangeDetectorRef,
    private title: Title,
    media: MediaMatcher,
    private sharedService: SharedService,
    private userService: UserService
  ) {
    this.show = ScreenId.WELCOME_SCREEN;
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);

    //To Check the Backup Write Permissions---Start
    this.userService
      .getPagePermissions(PermissionsList.RESTORE_WRITE)
      .subscribe((data) => {
        if (data.length > 0) {
          this.restorePermission.write = data[0].write;
        }
      });
  }
  //To Check the Backup Write Permissions---End

  onResize(event: any) {
    this.xsmall = event.target.innerWidth <= 599.98 ? 1 : 2; //599.98 large handset - small handset - xsmall - 4
    this.xsmallPopover = event.target.innerWidth <= 300 ? 1 : 2;
  }

  ngOnInit(): void {
    this.xsmall = window.innerWidth <= 599.98 ? 2 : 2; //480 large handset - small handset - xsmall - 4
    this.xsmallPopover = window.innerWidth <= 300 ? 1 : 2;

    this.sharedService._SMessage.subscribe((val) => {
      console.log('messagestoreeBackup', val);
      //this.titleElement = val;
      // eslint-disable-next-line no-debugger
      debugger;
    });

    this.title.setTitle('Restore');
    // this.sharedService.getRestoreDetailsCopy().subscribe((data) => {
    //   this.restoreDetails = data;
    // });

    // this.sharedService._SRestore_Data.subscribe((val) => {
    //   this.restoreDetails = val;
    //   console.log('restoreDetails', this.restoreDetails);
    // });

    // this.sharedService.getProjectDetails('Clarkson').subscribe((data) => {
    //   this.ddlProjectData = data;
    // });

    // this.sharedService.getPeriodsDetails().subscribe((data) => {
    //   this.ddlPeriodData = data;
    // });

    // this.sharedService.getEntityDetails().subscribe((data) => {
    //   this.ddlEntityData = data;
    // });
  }
  /*ngOnInit(): void {
    this.backupService.getProjectDetails().subscribe((data) => {
      this.ddlProjectData = data;
    });
    this.backupService.getPeriodsDetails().subscribe((data) => {
      this.ddlPeriodData = data;
    });
  }*/

  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }

  openDialog() {
    const dialogRef = this.dialog.open(ModelPopupComponent);

    dialogRef.afterClosed().subscribe((result) => {
      console.log(`Dialog result: ${result}`);
    });
  }
}

const DISPLAYCOLOUMNS = [
  'Entity',
  'Subentity',
  'Blob',
  'Initiated At',
  'Completed At',
  'Status',
  'Action',
];
