module.exports = {
  name: 'ado-vault.restore',
  exposes: {
    './Module': 'apps/ado-vault.restore/src/app/remote-entry/entry.module.ts',
  },
};
