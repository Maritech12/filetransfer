export const environment = {
  production: true,
  dashboard: 'http://localhost:4201',
  backup: 'http://localhost:4202',
  company: 'http://localhost:4203',
  entity: 'http://localhost:4204',
  integration: 'http://localhost:4205',
  userManagement: 'http://localhost:4206',
  report: 'http://localhost:4207',
  restore: 'http://localhost:4208',
  role: 'http://localhost:4209',
  storage: 'http://localhost:4210',
  notification: 'http://localhost:4211'
};
