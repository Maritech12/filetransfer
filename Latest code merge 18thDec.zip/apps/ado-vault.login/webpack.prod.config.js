const { withModuleFederation } = require('@nrwl/angular/module-federation');
const config = require('./module-federation.config');
module.exports = withModuleFederation({
  ...config,
       remotes: [
    ['ado-vault.dashboard', `https://vault-dev-ui.sea.live/remoteproject-dashboard`],
    ['ado-vault.backup',`https://vault-dev-ui.sea.live/remoteproject-backup`],
    ['ado-vault.company',`https://vault-dev-ui.sea.live/remoteproject-company`],
    ['ado-vault.entity',`https://vault-dev-ui.sea.live/remoteproject-entity`],
    ['ado-vault.integration',`https://vault-dev-ui.sea.live/remoteproject-integration`],
    ['ado-vault.user-management',`https://vault-dev-ui.sea.live/user-Management`],
    ['ado-vault.report',`https://vault-dev-ui.sea.live/remoteproject-report`],
    ['ado-vault.restore',`https://vault-dev-ui.sea.live/remoteproject-restore`],
    ['ado-vault.role',`https://vault-dev-ui.sea.live/remoteproject-role`],
    ['ado-vault.storage',`https://vault-dev-ui.sea.live/remoteproject-storage`],
    ['ado-vault.notification',`https://vault-dev-ui.sea.live/remoteproject-notification`]
  ]
  /*
   * Remote overrides for production.
   * Each entry is a pair of an unique name and the URL where it is deployed.
   *
   * e.g.
   * remotes: [
   *   ['app1', 'https://app1.example.com'],
   *   ['app2', 'https://app2.example.com'],
   * ]
   */
});
