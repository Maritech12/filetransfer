module.exports = {
  name: 'ado-vault.notification',
  exposes: {
    './Module':
      'apps/ado-vault.notification/src/app/remote-entry/entry.module.ts',
  },
};
