import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
@Component({
  selector: 'ado-bcp-ui-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss'],
})
export class DropdownComponent {
  @Input() ddlElement: any;  
  public modeselect = 'Select';
  @Input() ddlSelElement: any;
  @Output() ddlOnChanged: EventEmitter<any> = new EventEmitter<any>();

  constructor() {}
}
