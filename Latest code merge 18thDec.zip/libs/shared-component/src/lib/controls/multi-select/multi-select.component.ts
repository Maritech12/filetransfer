/*import { SharedService } from '@ado-bcp-ui/core';
import { Component, Input, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'ado-bcp-ui-multi-select',
  templateUrl: './multi-select.component.html',
  styleUrls: ['./multi-select.component.scss'],
})
export class MultiSelectComponent implements OnInit {
  @Input() ddlElement: any;
  @Input() ddlElementType: any;
  selectedOption = 'option0';
  constructor(private sharedService: SharedService) {}
  ngOnInit(): void {}

  selectProject(event: any) {
    switch (event.currentTarget.id) {
      case 'repository':
        break;
      case 'subEntity':
        break;
    }
  }
}
*/

import { SharedService } from '@ado-bcp-ui/core';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatSelect } from '@angular/material/select';
declare var $: any;
@Component({
  selector: 'ado-bcp-ui-multi-select',
  templateUrl: './multi-select.component.html',
  styleUrls: ['./multi-select.component.scss'],
})
export class MultiSelectComponent implements OnInit {
  @Input() ddlElement: any;
  selectedOption = 'option0';
  public modeselect = 'Select';
  selectedMulti!: any[];
  @Output() ddlOnChanged: EventEmitter<any> = new EventEmitter<any>();
  @Output() ddlOnSelectAll: EventEmitter<any> = new EventEmitter<any>();
  @Output() ddlOnSelectClick: EventEmitter<any> = new EventEmitter<any>();
  @Output() ddlOnOk: EventEmitter<any> = new EventEmitter<any>();
  @Output() ddlOnCancel: EventEmitter<any> = new EventEmitter<any>();
  
  constructor() {}
  ngOnInit(): void {}

  selectOne(select: MatSelect){
    select.value= select.value;
  }

  selectAll(select: MatSelect, values: any) {
    select.value = values;
    //array = values;
  }

  deselectAll(select: MatSelect) {
    select.value = [];
  }

  ok(select: MatSelect) {
    $('#multiSelect').modal('show');
  }
  cancel(select: MatSelect) {
    select.value = [];
    $('#multiSelect').modal('hide');
  }
}


