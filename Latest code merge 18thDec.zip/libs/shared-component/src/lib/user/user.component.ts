import { Component, OnInit } from '@angular/core';
import { MsalService } from '@azure/msal-angular';
import { Iuser, UserService } from '@ado-bcp-ui/core';

@Component({
  selector: 'ado-bcp-ui-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss'],
})
export class UserComponent implements OnInit {
  user: any = {
    userName: '',
    userNameLabel: 'Username',
    settingsLabel: 'Settings',
    logoutLabel: 'Logout',
  };
  userDetails!: Iuser;
  constructor(
    private userService: UserService,
    private msalService: MsalService
  ) {}

  ngOnInit(): void {
    this.userDetails=this.userService.getCurrentUserDetails();
  }

  logout() {
    this.userService.purgeAuth();
    this.msalService.logout();
  }
}
