/* eslint-disable @nrwl/nx/enforce-module-boundaries */

import { Injectable } from '@angular/core';
import { BehaviorSubject, map, Observable, ReplaySubject, Subject } from 'rxjs';
import {
  ApiService,
  ImenuElement,
  InotificationElement,
  IpopupElement,
  ItileElement,
  environment,
  ICreateOnScheduleBackup,
  ICreateOnDemandBackup,
  IRepository,
  IRepoSubentity,
  IEntity,
  IPeriod,
  IPermissions,
  IRestore,
  Iuser,
  IpopoverElement,
  IOnDemandBackup,
  IOnScheduleBackup,
  IBackupModel,
} from '@ado-bcp-ui/core';

import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class SharedService {

  private currentUserSubject = new BehaviorSubject<Iuser>({} as Iuser);

  // public backupOnDemandSubject = new BehaviorSubject<IBackupModel>({} as IBackupModel);
  // public backupOnScheduleSubject = new BehaviorSubject<IBackupModel>({} as IBackupModel);

  public _SProject_Data = new Subject<any>();
  public _STile_Data = new Subject<any>();
  public _SBackup_Data = new Subject<any>();
  public backupOnDemandSubject = new Subject<any>();
  public backupOnScheduleSubject = new Subject<any>();
  public _SRestore_Data = new Subject<any>();
  public _SEntity_Data = new Subject<any>();
  public _SMessage = new ReplaySubject<any>();
  public actionDetails!: any;

  constructor(private apiService: ApiService, private http: HttpClient) {}

  /*
   * This is a Description of the Action Details values set and get
   */
  set setaction(val: any) {
    this.actionDetails = val;
  }
  get getaction(): any {
    return this.actionDetails;
  }

  /*
   * This is a Description of the Get Backup Restore Details
   * @param This is the transactionId parameter
   */
  getBackupRestoreDetails(transactionId: string): Observable<any> {
    const params = new HttpParams().set('entityTransactionId', transactionId);
    return this.apiService
      .get(`${environment.api}/api/Report/GetTaskDetails`, params)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * This is a Description of the Get Task Details
   * @param This is the TransactionId parameter
   */
  getTaskDetails(transactionId: string): Observable<any> {
    const params = new HttpParams().set('TransactionId', transactionId);
    return this.apiService
      .get(`${environment.api}/api/Setting/GetTaskDetails`, params)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * This is a Description of Create OnDemandBackup
   * @param This is the OrganizationName,ProjectName,Entity and RepoIds parameter
   */
  createOnDemandBackup(paramsOnDemand: ICreateOnDemandBackup): Observable<any> {
    return this.apiService
      .post(`${environment.api}/api/ondemandbackup/repository`, paramsOnDemand)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * This is a Description of Create OnSchedule Backup
   * @param This is the OrganizationName,ProjectName,Entity,CronExpression and RepoId parameter
   */
  createOnScheduleBackup(
    paramsSchedule: ICreateOnScheduleBackup
  ): Observable<any> {
    return this.apiService
      .post(`${environment.api}/api/schedulebackup/repository`, paramsSchedule)
      .pipe(
        map((scheduleResponse) => {
          return scheduleResponse;
        })
      );
  }

  /*
   * This is a Description of Get OnDemand Backup
   * @param This is the TransactionType,isscheduled,ReportingPeriod,ProjectId,UserId parameter
   */
  getOnDemandBackup(ondemandBackup: IBackupModel): Observable<any> {
    const params = new HttpParams()
      .set('TransactionType', ondemandBackup.transactionType)
      .set('isscheduled', ondemandBackup.isscheduled)
      .set('ReportingPeriod', ondemandBackup.ReportingPeriod)
      .set('projectid', ondemandBackup.projectid)
      .set('userid', ondemandBackup.userid);

    return this.apiService
      .get(`${environment.api}/api/Report/GetDashboarddetails`, params)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * This is a Description of Get OnSchedule Backup
   * @param This is the UserId,ProjectId parameter
   */
  getonScheduleBackup(onScheduleBackup: IOnScheduleBackup): Observable<any> {
    const params = new HttpParams()
      .set('userid', onScheduleBackup.userid)
      .set('projectid', onScheduleBackup.projectid);
    return this.apiService
      .get(
        `${environment.api}/api/Setting/GetScheduleBackupTransaction`,
        params
      )
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * This is a Description of Get User Details
   * @param This is EmailId parameter
   */
  getUserDetailByEmailId(emailid: string): Observable<any> {
    const params = new HttpParams().set('Emailid', emailid);
    return this.apiService
      .get(
        `${environment.api}/api/UserManagement/GetUserDetailByEmailid`,
        params
      )
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * This is a Description of Get Project Details
   * @param This is organisationName parameter
   */
  getProjectDetails(projectDetails: string): Observable<any> {
    const params = new HttpParams().set('organisation', projectDetails);
    return this.apiService
      .get(`${environment.api}/api/setting/GetProjects`, params)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * This is a Description of Get Entity Details
   */
  getEntityDetails(): Observable<IEntity[]> {
    return this.apiService.get(`${environment.api}/api/setting/GetEntity`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  /*
   * This is a Description of Get Repository Details
   * @param This is organisationName,projectName parameter
   */
  getRepositoryDetails(repositoryDetails: IRepository): Observable<any> {
    const params = new HttpParams()
      .set('organizationName', repositoryDetails.organizationName)
      .set('projectName', repositoryDetails.projectName);
    return this.apiService
      .get(`${environment.api}/api/repositories`, params)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * This is a Description of Get Role Permissions Details
   */
  getRolePermissions(UserDetails: Iuser): Observable<IPermissions[]> {
    try {
      const params = new HttpParams().set('emailid', UserDetails.email);
      return this.apiService
        .get(`${environment.api}/api/setting/GetPermissionByEmailid`, params)
        .pipe(
          map((data: IPermissions[]) => {
            return data;
          })
        );
    } catch (error: any) {
      return error;
    }
  }

  /*
   * This is a Description of Get Repository SubEntity Details
   */
  getRepoSubEntityDetails(): Observable<IRepoSubentity[]> {
    return this.apiService
      .get(`${environment.api}/api/setting/GetSubEntity`)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * This is a Description of Get Notification Details
   */
  getNotificationDetails(): Observable<InotificationElement> {
    return this.apiService.get(`${environment.api_url}/notifications`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  /*
   * This is a Description of Get Backup Popup Details
   */
  getBackupPopupDetails(): Observable<IpopupElement> {
    return this.apiService.get(`${environment.api_url}/popupTitle`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  /*
   * This is a Description of Get Menu Details
   */
  getMenuDetails(): Observable<ImenuElement> {
    return this.apiService.get(`${environment.api_url}/menuElement`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  /*
   * This is a Description of Get Dashboard Tile Details
   */
  getDashboardTileDetails(): Observable<ItileElement> {
    return this.apiService.get(`${environment.api_url}/titleData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  /*
   * This is a Description of Get Periods Details
   */
  getPeriodsDetails(): Observable<IPeriod[]> {
    return this.apiService.get(`${environment.api_url}/ddlPeriodData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  /*
   * This is a Description of Get Backup Details
   */
  getBackupDetails() {
    return this.apiService.get(`${environment.api_url}/getBackupDetails`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  /*
   * This is a Description of Get View Backup Details
   */
  getViewBackup() {
    return this.apiService.get(`${environment.api_url}/viewData`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  /*
   * This is a Description of Get Restore Details
   */
  getRestoreDetailsCopy(): Observable<IRestore> {
    return this.apiService
      .get(`${environment.api_url}/getRestoreDetailsCopy`)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  /*
   * This is a Description of Get backup Popover Success Details
   */
  getBackupPopoverSuccessDetails(): Observable<IpopoverElement> {
    return this.apiService.get(`${environment.api_url}/popoverSuccess`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  /*
   * This is a Description of Get backup Popover Running Details
   */
  getBackupPopoverRunningDetails(): Observable<IpopoverElement> {
    return this.apiService.get(`${environment.api_url}/popoverRunning`).pipe(
      map((data) => {
        return data;
      })
    );
  }

  /*
   * This is a Description of Get backup Popover Failed Details
   */
  getBackupPopoverFailedDetails(): Observable<IpopoverElement> {
    return this.apiService.get(`${environment.api_url}/popoverFailed`).pipe(
      map((data) => {
        return data;
      })
    );
  }
}
