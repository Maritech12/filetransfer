interface IsubMenuElement {
  routerLink: string;
  icon: string;
  title: string;
}

interface ImenuElement {
  routerLink: string;
  icon: string;
  title: string;
  submenu: IsubMenuElement[];
}


export {
  ImenuElement
};
