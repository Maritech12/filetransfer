/* eslint-disable @angular-eslint/contextual-lifecycle */
import {
  ErrorList,
  IPermissions,
  Iuser,
  PageName,
  SharedService,
  UserService,
} from '@ado-bcp-ui/core';
import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import {
  MsalGuardConfiguration,
  MsalService,
  MSAL_GUARD_CONFIG,
} from '@azure/msal-angular';
import { RedirectRequest } from '@azure/msal-browser';
import { of, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class MSALLoginService {
  userDetails!: Iuser;
  private readonly _destroying$ = new Subject<void>();

  constructor(
    private sharedService: SharedService,
    private msalService: MsalService,
    private router: Router,
    private userService: UserService,
    private http: HttpClient,
    @Inject(MSAL_GUARD_CONFIG)
    private msalGuardConfiguration: MsalGuardConfiguration
  ) {}

  msallogin() {
    //To check the user is Authenticated or not
    this.msalService.instance.handleRedirectPromise().then((msalResponse) => {
      if (msalResponse != null && msalResponse.account != null) {
        this.msalService.instance.setActiveAccount(msalResponse.account);
        this.userDetails = {
          email: msalResponse.account.username,
          token: msalResponse.accessToken,
          name: msalResponse.account.name,
          username: msalResponse.account.name,
          permissions: [],
        };
        this.userService.setAuth(this.userDetails);
        //To get the user roles and permissions
        of(
          this.sharedService.getRolePermissions(this.userDetails).subscribe({
            next: (permissionListData: IPermissions[]) => {
              if (permissionListData.length > 0) {
                this.userDetails.permissions = permissionListData;
                this.userService.setAuth(this.userDetails);
                this.router.navigate([PageName.DASHBOARD]);
              } else {
                this.logIn();
              }
            },
          })
        );
      } else {
        this.logIn();
      }
    });
  }

  logIn() {
    // Clearded the token and redirected to Login page
    this.userService.purgeAuth();
    this.msalService.loginRedirect({
      ...this.msalGuardConfiguration.authRequest,
    } as RedirectRequest);
  }
}
